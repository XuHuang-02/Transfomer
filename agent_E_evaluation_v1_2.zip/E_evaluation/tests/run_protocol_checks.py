"""Run reference contract regressions; never calls a model or signs customer labels."""
import copy
import json
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
sys.path.insert(0,str(ROOT/'common'))
from protocol_reference import *
from legacy_test_helpers import make_draft, negative_run
import source_prepare as prep
ROOT=HERE.parent.parent

fixtures=json.loads((HERE/'protocol_fixtures_v1_2.json').read_text())
examples={e['name']:e for e in fixtures['examples']}
results=[]



def assert_one(items):
    assert len(items)==1 and items[0]['issueId']=='ISSUE_001'

def assert_empty(items):
    assert not items

def test(name,fn,kind='revision',expected_code=None):
    try:
        fn()
        if expected_code:
            raise AssertionError('invalid artifact accepted, expected '+expected_code)
        results.append({'name':name,'kind':kind,'passed':True})
    except Exception as e:
        actual=getattr(e,'code',None)
        ok=bool(expected_code and actual==expected_code)
        results.append({'name':name,'kind':kind,'passed':ok,**({'actualCode':actual,'expectedCode':expected_code} if expected_code else {'error':str(e)})})


def positive(ex):
    prep.validate_against_raw(ex['context'],ex['rawText'])
    decision=mapped_decision(ex)
    for key in ['classification','reporting','riskGradeAction']:
        assert decision[key]==ex['expected'][key],key
    if ex['expected'].get('constraintKind'):
        assert ex['expected']['constraintKind'] in [b['kind'] for b in decision['constraintDescriptors']]
    if ex['expected'].get('reason'):assert decision['reason']==ex['expected']['reason']
    if ex['assessment']:
        draft=make_draft(ex,decision)
        validate_draft(ex,decision,draft)
        for node,payload in {'EXTRACT':ex['extraction'],'ASSESS':ex['assessment'],'REVIEW':{'issues':[]},'WRITE':draft}.items():
            validate_response(node,{'status':'COMPLETED','result':payload,'pipelineFindings':[]})


for ex in examples.values():test(ex['name'],lambda ex=ex:positive(ex),'legacy_positive')
for n in fixtures['negativeExamples']:test(n['name'],lambda n=n:negative_run(n,examples),'legacy_negative',n['expectedCode'])
for t in fixtures['triStateExamples']:
    def run(t=t):
        x=t['inputs']
        actual=('NOT_MET' if 'NOT_MET' in x else ('MET' if all(v=='MET' for v in x) else 'UNKNOWN')) if t['operator']=='AND' else ('MET' if 'MET' in x else ('NOT_MET' if all(v=='NOT_MET' for v in x) else 'UNKNOWN'))
        assert actual==t['expected']
    test(t['name'],run,'legacy_tri_state')

sample_raw=(ROOT/'B_data/DEV_001_raw.txt').read_text()
ind=prep.prepare_context(sample_raw,'INDEPENDENT','scope_tests')
comp=prep.prepare_context(sample_raw,'COMPREHENSIVE','scope_tests')
raw_without_original=sample_raw.split('<原评估>')[0]
comp_no_original=prep.prepare_context(raw_without_original,'COMPREHENSIVE','no_original')


def good_scope():
    assert [b['sectionId'] for d in ind['documents'] for b in d['blocks']]==['BASE_1','BASE_2','BASE_5']
    assert '（3）客户个人（家庭）年收入：10万元' not in prep.render_input(ind)
    assert '20000元' in prep.render_input(ind)
    assert '12. 是否涉及司法查冻扣案件？是。' in prep.render_input(ind)
    assert '14. 其他可疑情形或不合理行为？否。' in prep.render_input(ind)
    assert ind['rawDigest']==comp['rawDigest'] and ind['viewDigest']!=comp['viewDigest']
    for value in [ind,comp]:prep.validate_against_raw(value,sample_raw);validate_sources(value)


test('two_views_exact_scope_and_nested_items',good_scope)
def comprehensive_without_original():
    validate_sources(comp_no_original)
    assert comp_no_original['mode']=='COMPREHENSIVE' and not any(d['origin']=='ORIGINAL' for d in comp_no_original['documents'])
test('comprehensive_without_original_keeps_mode',comprehensive_without_original)


def injected_text():
    c=copy.deepcopy(ind);c['documents'][0]['text']+='\n隐藏收入10万元';c['viewDigest']=prep.view_digest(c);validate_sources(c)
test('hidden_text_outside_visible_blocks',injected_text,expected_code='INPUT_SCOPE_ERROR')


def injected_block():
    c=copy.deepcopy(ind);c['documents'][0]['blocks'].append(copy.deepcopy(comp['documents'][0]['blocks'][2]))
    c['documents'][0]['text']='\n\n'.join(b['text'] for b in c['documents'][0]['blocks']);c['viewDigest']=prep.view_digest(c);validate_sources(c)
test('hidden_section_inside_BASE',injected_block,expected_code='INPUT_SCOPE_ERROR')


def forged_section():
    c=copy.deepcopy(ind);b=copy.deepcopy(comp['documents'][0]['blocks'][2]);b.update(sectionId='BASE_5',blockId='BASE_5')
    c['documents'][0]['blocks'][-1]=b;c['documents'][0]['text']='\n\n'.join(b['text'] for b in c['documents'][0]['blocks']);c['viewDigest']=prep.view_digest(c)
    prep.validate_against_raw(c,sample_raw)
test('forged_section_tag_fails_raw_reconstruction',forged_section,expected_code='INPUT_SCOPE_ERROR')
test('excluded_quote_even_if_in_raw',lambda:validate_quote(ind,{'sourceId':'BASE','blockId':'BASE_3','quote':'客户个人（家庭）年收入：10万元'}),expected_code='EVIDENCE_NOT_FOUND')
test('boundary_missing_is_execution_failure',lambda:prep.prepare_context(sample_raw.replace('3. 经营情况与收入来源','经营信息'),'INDEPENDENT','bad'),expected_code='SOURCE_SECTION_ERROR')
test('duplicate_heading_is_execution_failure',lambda:prep.prepare_context(sample_raw.replace('3. 经营情况与收入来源','3. 经营情况与收入来源\n3. 经营情况与收入来源'),'INDEPENDENT','bad'),expected_code='SOURCE_SECTION_ERROR')


def allowed_business_in_five():
    raw=sample_raw.replace('</基础资料>','补充说明：客户申报个人年收入10万元。\n</基础资料>')
    c=prep.prepare_context(raw,'INDEPENDENT','allowed_business');prep.validate_against_raw(c,raw)
    validate_quote(c,{'sourceId':'BASE','blockId':'BASE_5','quote':'补充说明：客户申报个人年收入10万元。'})
test('business_words_inside_allowed_section_remain_usable',allowed_business_in_five)

base=copy.deepcopy(next(e for e in examples.values() if e['assessment'] and e['assessment']['suspicion']['status']=='ESTABLISHED'))


def focus_unknown_general():
    e=copy.deepcopy(base)
    for f in e['assessment']['focusFindings']:f.update(status='UNDETERMINED',factIds=[],explanation='仅给定协议状态，未确认重点条件。')
    assert mapped_decision(e)['classification']=='GENERAL_SUSPICIOUS'
test('established_and_all_focus_unknown_maps_general',focus_unknown_general)


def simultaneous_focus():
    e=copy.deepcopy(base)
    for f in e['assessment']['focusFindings']:
        if f['condition'] in ['FOCUS_1','FOCUS_3']:
            f.update(status='SUPPORTED',factIds=e['assessment']['suspicion']['factIds'],explanation='给定条件有支持，仅检验多条件映射，不充当语义正例。')
    assert mapped_decision(e)['classification']=='FOCUS_SUSPICIOUS'
test('given_focus_one_and_three_can_coexist',simultaneous_focus)


def empty_conflict():
    e=copy.deepcopy(base);e['context']['emptyFactsConfirmed']=True;e['extraction']={'facts':[],'originalStatements':[],'conflicts':[],'readingNotes':[]}
    mapped_decision(e)
test('confirmed_empty_cannot_swallow_nonempty_assessment',empty_conflict,expected_code='INCONSISTENT_ASSESSMENT')


def wrong_binding():
    validate_binding(prep.binding(comp),ind)
test('cross_mode_node_binding_rejected',wrong_binding,expected_code='STALE_ARTIFACT')


def wrong_stamp(field):
    s=dict(prep.binding(ind),node='ASSESS',artifactRevision=1,consumedRevisions={'source':3,'facts':1})
    expected=copy.deepcopy(s)
    if field=='sourceRevision':s[field]=1
    elif field=='inputProfileVersion':s[field]='1.0'
    elif field=='viewDigest':s[field]='0'*64
    elif field=='ruleSnapshotSha256':s[field]='0'*64
    check_stamp(s,expected)
for field in ['sourceRevision','viewDigest']:
    test('stale_stamp_'+field,lambda field=field:wrong_stamp(field),expected_code='STALE_ARTIFACT')
for field in ['inputProfileVersion','ruleSnapshotSha256']:
    test('old_const_stamp_'+field,lambda field=field:wrong_stamp(field),expected_code='OUTPUT_SCHEMA_ERROR')


def bad_extractor_payload():
    p={'binding':prep.binding(ind),'ruleVersion':'1.2','documents':comp['documents']};validate_node_input('EXTRACT',p,ind)
test('extractor_cannot_receive_full_document_with_independent_binding',bad_extractor_payload,expected_code='INPUT_SCOPE_ERROR')


def blocker(bid,key,affected=None):
    return {'blockerId':bid,'causeKey':key,'kind':'INPUT_GAP','affectedResults':affected or ['CLASSIFICATION'],
            'factIds':[],'conflictIds':[],'checkedSourceIds':['BASE'],'missingConcept':'给定决定性命题',
            'decisiveReason':'给定成立的限制，仅测试组装，不认定真实客户缺项。'}


def decision(bs):return {'constraintDescriptors':bs}


def no_original_no_blockers():
    assert assemble_issues(comp_no_original,decision([]))==[]
    assert not any(d['origin']=='ORIGINAL' for d in comp_no_original['documents'])
test('no_original_no_blocker_no_numbered_issue',no_original_no_blockers)
test('no_original_with_blocker_builds_ordinary_issue',lambda:assert_one(assemble_issues(comp_no_original,decision([blocker('A','gap:a')]))))


def assert_one(items):
    assert len(items)==1 and items[0]['issueId']=='ISSUE_001'


def duplicate_same_root():
    x=assemble_issues(comp_no_original,decision([blocker('A','gap:a'),blocker('B','gap:a')]))
    assert_one(x);assert x[0]['blockerIds']==['A','B']
test('duplicate_limitations_same_cause_merge',duplicate_same_root)


def original_issue(key='gap:a',related=None):
    return {'issueId':'R1','causeKey':key,'kind':'LOGIC_ERROR','factIds':[],'evidence':[],
            'problem':'给定原文逻辑问题。','suggestion':'按已有事实修正。','relatedBlockerIds':related or []}


def combined_same_root():
    x=assemble_issues(comp,decision([blocker('A','gap:a')]),{'issues':[original_issue(related=['A'])]})
    assert_one(x);assert x[0]['origin']=='COMBINED' and x[0]['sourceIssueIds']==['R1']
test('original_and_limitation_same_cause_merge',combined_same_root)


def distinct_root():
    x=assemble_issues(comp_no_original,decision([blocker('A','gap:a'),blocker('B','grade:b',['RISK_GRADE'])]))
    assert len(x)==2 and x[0]['issueId']=='ISSUE_001' and x[1]['issueId']=='ISSUE_002'
test('different_causes_and_results_do_not_merge',distinct_root)
test('related_blocker_cause_mismatch_rejected',lambda:assemble_issues(comp,decision([blocker('A','gap:a')]),{'issues':[original_issue('gap:b',['A'])]}),expected_code='INCONSISTENT_ISSUE_CAUSE')
test('no_original_cannot_fabricate_original_issue',lambda:assemble_issues(comp_no_original,decision([]),{'issues':[original_issue()]}),expected_code='REVIEW_OVERREACH')
test('independent_never_assembles_problem_list',lambda:assert_empty(assemble_issues(ind,decision([blocker('A','gap:a')]))))


def assert_empty(items):assert not items


def reference_structure():
    check_schema_references(bundle['schema']);assert len(bundle['ruleIds'])==len(set(bundle['ruleIds']))==47
    assert not set(bundle)&{'examples','negativeExamples','triStateExamples','validationReport'}
    assert digest_file(ROOT/'common/business_rules_v1_2.md')==bundle['ruleSnapshotSha256']


def digest_file(path):return prep.digest_text(path.read_text())
test('schema_local_refs_47_rules_and_runtime_isolation',reference_structure,'release_structure')


def model_cannot_approve():
    a=json.loads((ROOT/'common/annotation_template_v1_2.json').read_text())
    task=json.loads((ROOT/'tasks/DEV_001_INDEPENDENT/task.json').read_text())
    a['meta']=copy.deepcopy(task['meta']);a['coordinatorOnly']['annotationStatus']='APPROVED'
    validate_annotation(a,task,ind)
# Same request binding except requestId is intentionally not part of annotation metadata.
test('model_cannot_sign_gold_labels',model_cannot_approve,expected_code='OUTPUT_SCHEMA_ERROR')



def second_section_quote_is_available():
    validate_quote(ind,{'sourceId':'BASE','blockId':'BASE_2','quote':'| 银行代理 | 8026000021221738 | 阳光财富两全保险（分红型） | 2012/3/10 | 20000元 | 32060元 | 转账 |'})
    assert '销售机构' in ind['documents'][0]['blocks'][1]['text']
test('second_section_business_table_and_quote_preserved',second_section_quote_is_available)


def narrow_view_missing_second_section():
    c=copy.deepcopy(ind)
    c['documents'][0]['blocks']=[b for b in c['documents'][0]['blocks'] if b['sectionId']!='BASE_2']
    c['documents'][0]['text']='\n\n'.join(b['text'] for b in c['documents'][0]['blocks'])
    c['viewDigest']=prep.view_digest(c)
    prep.validate_against_raw(c,sample_raw)
test('narrow_view_cannot_drop_existing_allowed_second_section',narrow_view_missing_second_section,expected_code='INPUT_SCOPE_ERROR')


def fourth_section_funding_is_out_of_scope():
    validate_quote(ind,{'sourceId':'BASE','blockId':'BASE_4','quote':'客户投保/加保资金来源：客户家庭收入以及存款。'})
test('fourth_section_funding_remains_excluded',fourth_section_funding_is_out_of_scope,expected_code='EVIDENCE_NOT_FOUND')


def independent_second_section_is_exact_raw_slice():
    actual=next(b for b in ind['documents'][0]['blocks'] if b['sectionId']=='BASE_2')
    expected=next(b for b in comp['documents'][0]['blocks'] if b['sectionId']=='BASE_2')
    assert actual==expected
    assert sample_raw[actual['rawStart']:actual['rawEnd']]==actual['text']
test('second_section_preserves_raw_text_and_offsets',independent_second_section_is_exact_raw_slice)

report={'releaseVersion':'1.2','protocolVersion':bundle['protocolVersion'],'ruleVersion':bundle['businessRuleVersion'],
        'schemaDefinitions':len(defs),'ruleCount':len(bundle['ruleIds']),
        'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results),
        'countsByKind':{k:sum(r['kind']==k for r in results) for k in sorted({r['kind'] for r in results})},
        'scope':'JSON解析、本协议所用schema关键字子集、给定状态的映射、引用、输入范围、版本及问题合并。',
        'notCovered':['生产JSON Schema库与供应商结构化输出兼容性','真实模型的事实和业务语义正确率','项目接口集成','最终客户标签签发'],
        'modelCalls':0,'approvedCustomerLabels':0,'projectIntegration':'NOT_RUN','results':results}
(HERE/'protocol_validation_v1_2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'},ensure_ascii=False,indent=2))
for r in results:
    if not r['passed']:print(json.dumps(r,ensure_ascii=False))
if report['failed']:raise SystemExit(1)
