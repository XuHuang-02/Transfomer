from protocol_reference import *
import source_prepare

def make_draft(example, decision):
    labels = {
        'GENERAL_SUSPICIOUS': '本轮业务存在具体涉案资金联系线索，形成合理怀疑，按一般可疑处理。',
        'FOCUS_SUSPICIOUS': '本轮业务存在具体涉案资金联系线索，且有关继续转移安排具有紧迫性，按重点可疑处理。',
        'NO_ML_RISK': '合同约定的续期业务及对应账户核查支持合理解释，本次覆盖业务可排除洗钱嫌疑。',
        'INSUFFICIENT': '本次暂不形成可疑程度及上报结论。',
    }
    text = labels[decision['classification']]
    constraint_refs = []
    for blocker in decision['constraintDescriptors']:
        detail = 'CAUSE_AND_STATUS' if example['context']['mode'] == 'INDEPENDENT' else 'STATUS_ONLY'
        constraint_refs.append({'blockerId': blocker['blockerId'], 'detail': detail})
        if detail == 'CAUSE_AND_STATUS' and 'CLASSIFICATION' in blocker['affectedResults']:
            text = '决定本轮资金关联的付款完成状态存在实质冲突，本次暂不形成分类。'
    descriptors = issue_descriptors(example['context'], decision)
    issues = [{'issueId': x['issueId'], 'problem': '决定相应判断的限制确实影响本轮结论。', 'suggestion': '保留已能成立的判断，暂不形成受限制的相应结论。'} for x in descriptors]
    return {'issues': issues, 'sections': [{'kind': 'CONCLUSION', 'paragraphs': [{'text': text, 'factIds': decision['basisFactIds'], 'decisionRefs': ['CLASSIFICATION'], 'constraintRefs': constraint_refs}]}]}


def negative_run(test, examples):
    ex = copy.deepcopy(examples[test['base']])
    m = test['mutation']
    if m == 'SET_MODE_INDEPENDENT_KEEP_ORIGINAL_FACT':
        ex['context'] = source_prepare.prepare_context(ex['rawText'], 'INDEPENDENT', ex['context']['requestId'], ex['context']['sourceRevision'], ex['context']['emptyFactsConfirmed'])
    elif m == 'SET_MODE_INDEPENDENT_KEEP_ORIGINAL_DOCUMENT':
        ex['context']['mode'] = 'INDEPENDENT'
    elif m == 'REPLACE_QUOTE_WITH_ABSENT_TEXT':
        ex['extraction']['facts'][0]['evidence'][0]['quote'] = '原文没有这句金额和账户断言。'
    elif m == 'CLEAR_SUSPICION_FACT_IDS':
        ex['assessment']['suspicion']['factIds'] = []
    elif m == 'ADD_UNKNOWN_FACT_REFERENCE':
        ex['assessment']['suspicion']['factIds'].append('F_DOES_NOT_EXIST')
    elif m == 'UNDETERMINE_REASONABLE_EXPLANATION':
        ex['assessment']['noRiskCriteria']['reasonableExplanation']['status'] = 'UNDETERMINED'
    elif m == 'ADD_CLASSIFICATION_BLOCKER_TO_ESTABLISHED':
        ex['assessment']['materialBlockers'] = [{'blockerId': 'L_BAD', 'causeKey': 'gap:test', 'kind': 'INPUT_GAP', 'affectedResults': ['CLASSIFICATION'], 'factIds': [], 'conflictIds': [], 'checkedSourceIds': [d['sourceId'] for d in ex['context']['documents']], 'missingConcept': 'a missing detail', 'decisiveReason': 'An inconsistent claim that classification is blocked.'}]
    elif m == 'CLEAR_SUPPORTED_FOCUS_FACT_IDS':
        ex['assessment']['focusFindings'][2]['factIds'] = []
    elif m == 'CLEAR_CHECKED_SOURCE_IDS':
        raw=ex['rawText']
        if '<原评估>' not in raw: raw += '\n<原评估>原评估另有付款记载。</原评估>'
        ex['context']=source_prepare.prepare_context(raw,'COMPREHENSIVE',ex['context']['requestId'],ex['context']['sourceRevision'])
    elif m == 'CLEAR_ALL_FACTS':
        ex['extraction']['facts'] = []
    elif m == 'MARK_GRADE_SOURCE_PROPOSED':
        ex['extraction']['facts'][0]['data']['gradeRecordState'] = 'PROPOSED'
    elif m == 'STAMP_OLD_FACT_REVISION':
        stamp = dict(source_prepare.binding(ex['context']), node='ASSESS', artifactRevision=1, consumedRevisions={'source':3,'facts':1})
        expected = copy.deepcopy(stamp)
        expected['consumedRevisions']['facts'] = 2
        check_stamp(stamp, expected)
        return
    elif m == 'PASS_CLASSIFICATION_AS_INFERENCE':
        payload = {'binding': source_prepare.binding(ex['context']), 'facts': ex['extraction']['facts'], 'inferenceClaims': ex['extraction']['originalStatements'], 'conflicts': [], 'attentionFindings': []}
        shape(defs['AssessmentInput'], payload)
        return
    elif m == 'REVIEW_REPORTS_EXTRACTOR_OMISSION':
        review = {'status': 'REPAIR_REQUIRED', 'result': None, 'pipelineFindings': [{'code': 'FACT_OMISSION', 'targetNode': 'EXTRACT', 'detail': 'Simulated request to repair an omitted stated check result.', 'factIds': [], 'evidence': []}]}
        validate_response('REVIEW', review)
        if review['pipelineFindings']:
            fail(review['pipelineFindings'][0]['code'], 'repair extractor, do not publish as original issue')
        return
    elif m in ['COMPLETED_WITH_NULL_RESULT', 'REPAIR_WITH_NON_NULL_RESULT', 'ASSESSMENT_REQUESTS_WRITE_REPAIR']:
        response = {'status': 'COMPLETED', 'result': ex['assessment'], 'pipelineFindings': []}
        if m == 'COMPLETED_WITH_NULL_RESULT':
            response['result'] = None
        else:
            response['status'] = 'REPAIR_REQUIRED'
            response['pipelineFindings'] = [{'code': 'FACT_OMISSION', 'targetNode': 'EXTRACT', 'detail': 'Protocol repair example.', 'factIds': [], 'evidence': []}]
            if m == 'ASSESSMENT_REQUESTS_WRITE_REPAIR':
                response['result'] = None
                response['pipelineFindings'][0]['targetNode'] = 'WRITE'
        validate_response('ASSESS', response)
        return
    else:
        decision = mapped_decision(ex)
        draft = make_draft(ex, decision)
        if m == 'ADD_WRITER_CLASSIFICATION_FIELD':
            draft['classification'] = 'FOCUS_SUSPICIOUS'
        elif m == 'ADD_CURRENT_BUSINESS_SECTION':
            section = copy.deepcopy(draft['sections'][0])
            section['kind'] = 'CURRENT_BUSINESS'
            draft['sections'].insert(0, section)
        elif m == 'EMPTY_CONCLUSION_PARAGRAPHS':
            draft['sections'][0]['paragraphs'] = []
        elif m == 'WRITE_LIMIT_CAUSE_IN_COMPREHENSIVE_CONCLUSION':
            draft['sections'][0]['paragraphs'][0]['constraintRefs'][0]['detail'] = 'CAUSE_AND_STATUS'
        else:
            raise AssertionError(m)
        validate_draft(ex, decision, draft)
        return
    mapped_decision(ex)

