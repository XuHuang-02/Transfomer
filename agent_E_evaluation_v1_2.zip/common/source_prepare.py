"""Reference source preparation for input profile 1.2. Standard library only."""
import argparse
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BINDING_KEYS = ('requestId', 'mode', 'schemaVersion', 'ruleVersion', 'ruleSnapshotSha256',
                'inputProfileVersion', 'inputProfileDigest', 'sourceRevision', 'rawDigest', 'viewDigest')


class SourceError(ValueError):
    def __init__(self, code, detail):
        self.code, self.detail = code, detail
        super().__init__(f'{code}: {detail}')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def digest_text(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def resources():
    profile = json.loads((ROOT / 'input_profile_v1_2.json').read_text())
    versions = json.loads((ROOT / 'versions.json').read_text())
    return profile, versions


def normalize_raw(text):
    return text.replace('\r\n', '\n').replace('\r', '\n')


def tagged_range(raw, tag, required):
    opens = list(re.finditer(re.escape('<' + tag + '>'), raw))
    closes = list(re.finditer(re.escape('</' + tag + '>'), raw))
    if not opens and not closes and not required:
        return None
    if len(opens) != 1 or len(closes) != 1 or closes[0].start() < opens[0].end():
        raise SourceError('SOURCE_SECTION_ERROR', 'missing, repeated or reversed source delimiters')
    return opens[0].end(), closes[0].start()


def split_raw(text):
    raw = normalize_raw(text)
    a, z = tagged_range(raw, '基础资料', True)
    original_range = tagged_range(raw, '原评估', False)
    if original_range and original_range[0] < z:
        raise SourceError('SOURCE_SECTION_ERROR', 'overlapping source containers')
    profile, _ = resources()
    titles = profile['sectionTitles']
    candidates = []
    for match in re.finditer(r'(?m)^[ \t]{0,3}(?:#{1,6}[ \t]+)?([1-5])[.．、][ \t]*([^\n]+)', raw[a:z]):
        num, title = match.group(1), match.group(2).strip().rstrip('：:')
        expected = titles['BASE_' + num]
        if title == expected or (num == '2' and title.startswith(expected)):
            candidates.append((int(num), a + match.start()))
    if [n for n, _ in candidates] != [1, 2, 3, 4, 5]:
        raise SourceError('SOURCE_SECTION_ERROR', 'expected five unique ordered top-level headings; manual source adapter required')
    if raw[a:candidates[0][1]].strip():
        raise SourceError('SOURCE_SECTION_ERROR', 'unclassified preamble requires manual source adapter')
    blocks = []
    for i, (number, start) in enumerate(candidates):
        end = candidates[i + 1][1] if i < 4 else z
        blocks.append({'blockId': f'BASE_{number}', 'sectionId': f'BASE_{number}',
                       'text': raw[start:end], 'headerBlockIds': [], 'rawStart': start, 'rawEnd': end})
    original = None
    if original_range:
        start, end = original_range
        if raw[start:end].strip():
            original = {'blockId': 'ORIGINAL_1', 'sectionId': 'ORIGINAL', 'text': raw[start:end],
                        'headerBlockIds': [], 'rawStart': start, 'rawEnd': end}
    return raw, blocks, original


def view_digest(context):
    keys = ['mode', 'schemaVersion', 'ruleVersion', 'ruleSnapshotSha256', 'inputProfileVersion',
            'inputProfileDigest', 'sourceRevision', 'documents']
    return digest_text(canonical({k: context[k] for k in keys}))


def prepare_context(text, mode, request_id, source_revision=3, empty_facts_confirmed=False,
                    six_month_policy='UNSET'):
    profile, versions = resources()
    if mode not in profile['modes']:
        raise SourceError('INPUT_SCOPE_ERROR', 'unknown mode')
    raw, all_blocks, original = split_raw(text)
    allowed = profile['modes'][mode]['allowedSections']
    selected = [b for b in all_blocks if b['sectionId'] in allowed]
    docs = [{'sourceId': 'BASE', 'origin': 'BASE', 'text': '\n\n'.join(b['text'] for b in selected), 'blocks': selected}]
    if original and 'ORIGINAL' in allowed:
        docs.append({'sourceId': 'ORIGINAL', 'origin': 'ORIGINAL', 'text': original['text'], 'blocks': [original]})
    context = {'requestId': request_id, 'mode': mode, 'schemaVersion': versions['protocolVersion'],
               'ruleVersion': versions['ruleVersion'], 'ruleSnapshotSha256': versions['ruleSnapshotSha256'],
               'inputProfileVersion': profile['inputProfileVersion'],
               'inputProfileDigest': digest_text(canonical(profile)), 'sourceRevision': source_revision,
               'rawDigest': digest_text(raw), 'viewDigest': '', 'documents': docs,
               'emptyFactsConfirmed': empty_facts_confirmed, 'sixMonthWindowPolicy': six_month_policy}
    context['viewDigest'] = view_digest(context)
    return context


def binding(context):
    return {k: context[k] for k in BINDING_KEYS}


def validate_view(context):
    profile, versions = resources()
    for k, expected in [('schemaVersion', versions['protocolVersion']), ('ruleVersion', versions['ruleVersion']),
                        ('ruleSnapshotSha256', versions['ruleSnapshotSha256']),
                        ('inputProfileVersion', profile['inputProfileVersion']),
                        ('inputProfileDigest', digest_text(canonical(profile)))]:
        if context.get(k) != expected:
            raise SourceError('INPUT_SCOPE_ERROR', f'{k} does not match released resources')
    if context.get('mode') not in profile['modes']:
        raise SourceError('INPUT_SCOPE_ERROR', 'unknown mode')
    allowed = profile['modes'][context['mode']]['allowedSections']
    ids, seen_origins = set(), set()
    for doc in context['documents']:
        if doc['sourceId'] in ids or doc['origin'] in seen_origins:
            raise SourceError('INPUT_SCOPE_ERROR', 'duplicate document identity')
        ids.add(doc['sourceId']); seen_origins.add(doc['origin'])
        if doc['origin'] == 'ORIGINAL' and 'ORIGINAL' not in allowed:
            raise SourceError('INPUT_SCOPE_ERROR', 'original exposed to independent context')
        block_ids = [b['blockId'] for b in doc['blocks']]
        if len(set(block_ids)) != len(block_ids):
            raise SourceError('INPUT_SCOPE_ERROR', 'duplicate block identity')
        for block in doc['blocks']:
            section = block['sectionId']
            if section not in allowed or (doc['origin'] == 'ORIGINAL') != (section == 'ORIGINAL'):
                raise SourceError('INPUT_SCOPE_ERROR', 'excluded or mismatched source section')
            if not set(block['headerBlockIds']) <= set(block_ids):
                raise SourceError('INPUT_SCOPE_ERROR', 'header reference crosses visible document')
            if block['rawStart'] < 0 or block['rawEnd'] - block['rawStart'] != len(block['text']):
                raise SourceError('INPUT_SCOPE_ERROR', 'invalid Unicode codepoint span')
        if doc['text'] != '\n\n'.join(b['text'] for b in doc['blocks']):
            raise SourceError('INPUT_SCOPE_ERROR', 'document text differs from visible blocks')
    if context['viewDigest'] != view_digest(context):
        raise SourceError('INPUT_SCOPE_ERROR', 'view digest mismatch')


def validate_against_raw(context, raw_text):
    validate_view(context)
    expected = prepare_context(raw_text, context['mode'], context['requestId'], context['sourceRevision'],
                               context['emptyFactsConfirmed'], context['sixMonthWindowPolicy'])
    if context != expected:
        raise SourceError('INPUT_SCOPE_ERROR', 'prepared view does not match privileged raw-source reconstruction')


def render_input(context):
    validate_view(context)
    labels = {'BASE': '基础资料', 'ORIGINAL': '原评估'}
    return '\n\n'.join('<' + labels[d['origin']] + '>\n' + d['text'] + '\n</' + labels[d['origin']] + '>'
                         for d in context['documents']) + '\n'


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('raw', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--mode', choices=['INDEPENDENT', 'COMPREHENSIVE'], required=True)
    parser.add_argument('--request-id', required=True)
    parser.add_argument('--source-revision', type=int, default=3)
    args = parser.parse_args()
    value = prepare_context(args.raw.read_text(encoding='utf-8'), args.mode, args.request_id, args.source_revision)
    validate_against_raw(value, args.raw.read_text(encoding='utf-8'))
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'source_context.json').write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    (args.output / 'input.txt').write_text(render_input(value))
