当前业务规范为1.2，1.0已审查判断条款沿用；FA01输入范围按用户确认修订。本协议仍引用[第一阶段唯一规范](https://chatgpt.com/space/page_8fe37eede1708191b67e2b98b8ec772c)，不另立合理怀疑或重点可疑标准。

协议版本1.2.0-draft.1，含40项节点结构定义。外部仍输入和输出文字。[运行协议JSON](https://chatgpt.com/library?file_id=libfile_df26f5f65f4c8191b9594ad50eaa7a64&account_id=1e12037f-1378-4235-8d29-42cdb9f4e5ca)已与测试样例分开。新增必填绑定及来源字段，旧包必须迁移；本版完成69项参考协议检查，尚无真实模型或项目集成验收。

# 对外接口与输入范围

业务入口明确选择INDEPENDENT或COMPREHENSIVE，调用方不需要把客户资料改填成JSON字段。模式、规则版本、输入版本等由程序建立，不从客户文本里的指令决定。

独立模式INDEPENDENT只接收基础资料第1部分客户基本信息及类型、第2部分业务办理及交易情况、第5部分客户有无下列情况。综合模式COMPREHENSIVE接收第1至5部分及可空原评估。完整原文只在受信来源准备与回查端保留，不向独立节点提供被排除章节。两种模式继承同一客户的数据集归属，分别标注，结论允许不同。

SourceContext保存requestId、mode、schemaVersion、ruleVersion、ruleSnapshotSha256、inputProfileVersion、inputProfileDigest、sourceRevision、rawDigest、viewDigest及本模式SourceDocument。SourceBlock增加sectionId、rawStart、rawEnd，位置单位为规范化LF文本的Unicode码点。SourceDocument.text必须恰为可见块以两个LF连接；仅声明BASE来源或sectionId不能证明范围正确，SOURCE_PREPARE须对原文重建比对。表格及题干、选择、补充说明保留，不将第5部分内部小项误当一级章节。

职业、收入、账户、期间等客户属性仍可缺失，不为满足内部结构补值。固定排除的第3、4部分及原评估不算独立版漏抽，不自动成为SU05分类限制；业务判断仍检查本模式全部允许输入。章节边界识别失败走SOURCE_SECTION_ERROR执行错误。

# 统一节点响应

四个模型节点均使用下列响应框架；result的具体类型由调用节点确定。

```json
{
  "status": "COMPLETED",
  "result": {
    "issues": []
  },
  "pipelineFindings": []
}
```

示例中的result是无审视问题的ReviewResult；其他节点使用各自结果类型，完整可检验对象见协议JSON。请求修复时status为REPAIR_REQUIRED、result必须为null、pipelineFindings必须非空。完成时result必须非空且pipelineFindings为空。

真实业务暂缓仍是COMPLETED：评估结果中记录关键限制，程序形成相应待定结果。修复状态只表达执行或质量问题。节点跳过由程序记录SKIPPED，模型不能用跳过状态自行绕过必经步骤。

| 模型节点 | 完成后的result类型 | 可请求修复的节点 |
| --- | --- | --- |
| EXTRACT | ExtractionResult | SOURCE_PREPARE、EXTRACT |
| ASSESS | AssessmentResult | EXTRACT、ASSESS |
| REVIEW | ReviewResult | EXTRACT、ASSESS、REVIEW |
| WRITE | DraftReport | EXTRACT、ASSESS、REVIEW、WRITE |

被请求的修复必须经过程序验证目标、预算和版本；模型不能自行改写前序结果或调用未来节点。

# 事实整理节点

ExtractionInput包含InputBinding、本流程可见文档和规则版本。四节点输入均必填binding，程序验证其与SourceContext一致。ExtractionResult只整理记载，不生成最终分类、上报或等级操作。

| 字段 | 含义和约束 |
| --- | --- |
| facts | 具体事实记载；保留身份、申报、核查、涉嫌等性质 |
| originalStatements | 单独存放推断、评估结论、资金合法性判断和处理建议 |
| conflicts | 同口径冲突候选经比较后保留的冲突、所涉事实及解决状态 |
| readingNotes | 主体或范围不明等内部阅读说明，不自动变成客户异常或关键缺项 |

每条Fact包含factId、subjectText、subjectMatch、recordType、nature、statement、useStatus、useReason、evidence和data。nature包括RECORDED、DECLARED、CHECK_RESULT、ALLEGED；useStatus为AVAILABLE、SUPERSEDED或EXCLUDED，后两类必须说明有依据的原因。

data仍为可选属性集合，未适配事实保留statement和证据。原文已有且RF需要的日期、金额或账户关系应正确规范化，不能藏在statement后用UNKNOWN交差；没有的属性不补造。原账户与本人账户、申请与完成、个人与家庭收入保持原区别。

金额保存原文、口径、单位及精确或区间形式，数值使用十进制字符串。日期保留原文与日、月、年等精度，不为补全格式编造日号。data里的任何值均须有原文支持，规范化不是额外核实。

# 证据定位及可采用集合

EvidenceRef仍由sourceId、blockId、quote组成。程序检查当前模式章节、块及摘录唯一性；完整原文中存在而当前视图不允许的引用仍拒绝。视图定位与完整原文定位分开，裁剪后不沿用旧偏移。

引用不存在、引用含义之外的事实、来源越界和主体未匹配分别检查。证据存在只证明原文包含该片段，不证明模型推断正确。

程序从校验通过的Fact中构造当前可采用集合。后续决定性引用只能使用该集合的factId，保留替代或排除记录供审视回查。当前版本内factId唯一；前序修订后依据版本检查引用，不能把新事实与旧评估拼接。

facts为空时，若原文含实质内容且尚未确认无可采用事实，返回EMPTY_EXTRACTION_NEEDS_RECHECK。emptyFactsConfirmed由程序在确认空输入或完成空事实复核后记录，模型不能仅因抽取为空就启用ER02。

# 关注条件计算

程序依据已识别且有引用的属性形成AttentionFinding，记录findingId、ruleId、scopeKey、state、factIds及components。state使用MET、NOT_MET、UNKNOWN，组件记录相应事实及未知原因；具体条件引用RF01至RF06，组合依据RF08。

未知原因区分INPUT_NOT_PROVIDED、INPUT_AMBIGUOUS、SCOPE_INCOMPLETE和POLICY_PARAMETER_UNSET。RF07其他具体风险由评估节点按事实识别。所有内部关注结果都不直接成为报告里的命中说明或整体分类。

sixMonthWindowPolicy当前允许UNSET，表示RF01的精确算法尚未选定；不得静默改成180天。窗口边界参数在后续计算配置中明确，在此之前保留日期事实并区分配置未知与客户信息缺失。若配置缺失阻止正式运行所需的校验，走CONFIGURATION_NOT_SET，不生成客户缺项问题。其他可确定条件及判断按已批准规则继续处理。



## 关注与规范化监控

按mode和ruleId统计MET、NOT_MET、UNKNOWN及各UNKNOWN原因。原文已有却未提取的字段单列EXTRACTION_OR_NORMALIZATION_ERROR，不新增为客户风险原因。规范化与应计算目标的分母来自本模式人工复核参照；不使用模型自产记录当分母，不把固定排除部分计作漏抽；无适用目标记N/A。指标规范见monitoring_spec_v1_2.json。

# 风险评估节点

AssessmentInput含当前InputBinding、可采用事实、明确标注的推断主张、冲突及关注结果。原分类、资金合法性断言和处理建议不进入评估字段；同段有效事实继续保留。修复与回查也只限当前模式，不得借修复读取另一模式或旧缓存。

| 输出字段 | 含义 |
| --- | --- |
| suspicion | ESTABLISHED、NOT_ESTABLISHED或UNDETERMINED，附事实引用和简明关联解释 |
| noRiskCriteria | 未形成怀疑时逐项说明SU04的事实充分性、合理解释及无仍成立具体疑点；其他分支为null |
| focusEvaluation | 怀疑成立后为EVALUATED；否则为SKIPPED_BECAUSE_NOT_ESTABLISHED |
| focusFindings | 实际进入程度阶段时记录FOCUS_1、FOCUS_2、FOCUS_3及各自证据状态 |
| explanationEvaluation | 已有解释和核查的实际覆盖及作用 |
| otherAttentionSignals | RF07其他具体风险事实及解释 |
| materialBlockers | 确实阻止整体分类的INPUT_GAP或INPUT_CONFLICT，附影响、事实、冲突及检查范围 |
| currentGrade | KNOWN、UNKNOWN或CONFLICT；保留所选等级、依据及范围说明 |

重点条件仍为SUPPORTED、NOT_SUPPORTED、UNDETERMINED三态。FOCUS_1引用FO02，需分别解释具体保险行为及相关事实如何形成比一般怀疑更明确的犯罪活动指向；不能由“可能犯罪所得进入保险体系”自动成立，也不新增直接资金链或判决要求。同组事实可支持两层判断，FOCUS_1与FOCUS_3可同时成立。结构不能保证语义正确，仍需真实样本裁决。

KNOWN等级必须有明确现有状态或已生效变更的事实支持；拟调级或调整前等级不能作为现有等级。CONFLICT保留竞争记载，UNKNOWN不补值。等级限制随后由程序按currentGrade及MP03派生，不由评估节点再维护一份等级操作结论。

# 评估结果的一致性门槛

以下门槛落实SU与FO规则，不额外提高合理怀疑的证明要求。

- 怀疑成立必须有可采用事实引用和非空关联解释，进入重点阶段并覆盖三个条件。

- 未形成怀疑不自动进入无风险分支；noRiskCriteria三项须明确获得支持并说明依据。

- 无法形成分类须有具体materialBlockers，不能只写“缺乏解释”或“无法排除”。

- INPUT_GAP需指明决定性缺项，INPUT_CONFLICT需引用未解决的可比冲突；检查范围必须覆盖本流程全部允许输入。

- 已成立怀疑不能同时声称因关键缺项无法分类；仅重点条件无法确认按FO05处理。

- 未通过这些门槛属于INCONSISTENT_ASSESSMENT，回评估或必要的事实节点修正，不自动套用资料不足。

检查有字段、有引用、有解释只能建立可检查的接口约束，解释是否合理仍需要语义评测。

# 程序结果映射与问题组装

DecisionResult由程序依MP01至MP03生成，包括分类、上报、等级编码及中文标签、basisFactIds、constraintDescriptors。执行顺序见第一阶段MP01：先校验来源、引用、绑定和状态一致性；确认全空走ER02；怀疑成立且任一重点SUPPORTED走重点，否则包括有UNDETERMINED的情况走FO05一般；未成立且SU04三项支持走无风险；SU05真正阻止分类走资料不足；其他组合修复；最后独立映射等级。成文不能重新选择。

等级限制区分GRADE_UNKNOWN、GRADE_CONFLICT、GRADE_UNMAPPED。“最高风险”已明确而映射未覆盖时记录GRADE_UNMAPPED，不写成客户未提供等级。无洗钱风险的维持结果按MP03可确定时，不因等级名称未知或未覆盖而另行暂缓。

materialBlockers只表达真实分类限制，kind限INPUT_GAP或INPUT_CONFLICT且affectedResults为CLASSIFICATION；每项新增稳定causeKey。等级限制由程序独立派生，不能把仅等级受限混进分类限制。constraintDescriptors汇总最终限制，等级限制的causeKey按当前有效等级根因生成。

IssueDescriptor按causeKey合并ReviewIssue与最终限制，记录sourceIssueIds、blockerIds、factIds、affectedResults及可用问题建议。relatedBlockerIds必须引用同一根因，否则INCONSISTENT_ISSUE_CAUSE，回审视或评估核对，不凭文字相似合并。合并后顺序编号。同根因重复限制合一，不同根因不合并；无原评估且有关键限制仍生成普通问题，既无原文也无限制时仅保留RV04无原文说明。独立模式不生成问题清单。

# 原文审视节点

ReviewInput含当前InputBinding、可用原评估全文、事实结果、评估及程序映射。仅综合且有实质原评估时调用；无原评估仍是综合模式，由程序保留“本次无可供审视的原评估。”并按ER01组装限制问题。

ReviewResult只保存成立的原文问题。每项记录issueId、causeKey、kind、factIds、evidence、relatedBlockerIds、problem和suggestion，kind区分事实错误、重要遗漏、逻辑错误和结论超出依据。缺项按已有关键限制关联，避免与后续程序组装重复。

发现事实漏抽、确定性提升或评估层级错误时，通过统一响应的pipelineFindings请求对应前序修复，result为null。它们不是客户问题，也不把原评估独有事实改写成缺失。前序修复后重新执行必要审视，不能沿用已经失去依据的问题列表。

# 报告生成节点

WriterInput含当前InputBinding、模式、原评估是否存在、可采用事实、AssessmentResult、DecisionResult及已合并IssueDescriptor。模型输出DraftReport，不输出标题编号、固定三项或尾句。

| 草稿字段 | 约束 |
| --- | --- |
| issues | 只为已组装issueId生成问题及建议；不得新增、漏掉或改变问题身份 |
| sections | 使用IDENTITY、BUSINESS、FINANCIAL、CURRENT_BUSINESS、CHECKS、CONCLUSION等章节类型 |
| paragraphs | 非空自然段，保留factIds、decisionRefs及必要constraintRefs作为内部引用 |
| constraintRefs | 标明限制是CAUSE_AND_STATUS还是STATUS_ONLY，程序结合模式校验 |

章节类型唯一并按WR05顺序排列，CONCLUSION始终位于最后且一至两个自然段；独立模式不出现CURRENT_BUSINESS独立小节，不出现issues。

独立模式在结论中保留直接关键限制；综合模式在问题部分说明原因，结论只保留状态。程序检查constraintRefs的展示级别，语义复核再检查文本实际含义，不能仅靠模型自报标记证明没有重复原因。

若模型发现需要补看事实或重评，使用REPAIR_REQUIRED，不自行添加新事实或改选三项结果。渲染器最后按WR05、WR06添加标题、问题编号、固定结果和尾句。

# 共享状态与写入权限

共享状态由程序持有。完整原文在受信SOURCE_PREPARE与审计回查端保留；四节点只接收当前模式投影及本节点字段，不把完整共享状态整包传给模型。模型不能改写SourceContext、绑定或前序结果。

ArtifactStamp增加完整InputBinding字段，覆盖来源版本、模式、范围版本及摘要、规则快照、原文摘要和视图摘要；再记录node、artifactRevision和consumedRevisions。四节点及修复调用必须核对当前视图，不能用旧版事实或另一模式结果。

| 节点 | 必须绑定的前序版本 |
| --- | --- |
| EXTRACT | source |
| ASSESS | source、facts、attention |
| REVIEW | source、facts、assessment、decision |
| WRITE | source、facts、assessment、decision；执行过审视时再绑定review |

程序阶段状态使用PENDING、RUNNING、SUCCEEDED、SKIPPED、REPAIR_REQUIRED、FAILED、STALE。实际跳过的节点用SKIPPED，不能伪造一个空模型结果冒充成功。

源文、输入范围、视图摘要或规则快照变化使全部相关下游及缓存失效；事实变化使关注、评估、映射、审视和成文失效；评估变化使映射及下游失效；仅审视措辞变化通常影响组装与成文。修复不扩大输入范围。

# 运行状态与失败路由

| 类型或错误码 | 处理 |
| --- | --- |
| 真实关键缺项或冲突 | 正常完成评估，程序生成业务待定状态；不触发无限补事实重试 |
| EVIDENCE_OUT_OF_SCOPE、INPUT_SCOPE_ERROR | 停止发布，检查输入视图及证据范围，修复源输入或事实节点 |
| EVIDENCE_NOT_FOUND、EVIDENCE_AMBIGUOUS、REFERENCE_NOT_FOUND | 回到提交错误引用的节点，保留正确范围，不删除已有有效事实来凑合通过 |
| EMPTY_EXTRACTION_NEEDS_RECHECK、FACT_OMISSION | 回事实节点或范围准备，未确认前不触发全空模板 |
| INCONSISTENT_NODE_RESPONSE、OUTPUT_PARSE_ERROR、OUTPUT_SCHEMA_ERROR | 修复响应结构或该节点输出；不输出业务待定作为技术替代 |
| INCONSISTENT_ASSESSMENT、UNSUPPORTED_ASSOCIATION、SEVERITY_LEVEL_MIXED | 回评估；若根因是事实错误则先回事实 |
| REVIEW_OVERREACH | 回审视，前序事实或判断确需修正时走更早节点 |
| REPORT_FACT_DRIFT、REPORT_FORMAT_VIOLATION | 回成文；根因属于前序时按事实或评估修复 |
| RESULT_MAPPING_ERROR | 程序重做映射并使相关下游失效 |
| STALE_ARTIFACT | 丢弃失效结果，使用当前依赖重新执行 |
| CONFIGURATION_NOT_SET | 保留配置故障身份，按影响范围处理，不能写成客户缺项 |
| LLM_TIMEOUT、LLM_CALL_FAILED | 按总预算进行有限重试或失败 |
| REPAIR_BUDGET_EXHAUSTED | 结束并返回生成失败，不发布未通过正式报告 |

PipelineError保存错误码、阶段、类型、诊断、是否可重试、修复目标及受影响结果。模型请求修复先由程序验证，多个错误优先处理最早的共同前序根因，再重新计算受影响下游。

总时间、调用和修复预算由工程配置控制。真实缺项不消耗重试以编造事实；配置或调用失败也不能改成资料不足。

# 最终返回对象

PipelineResult是内部到外部适配器的结果：status、reportText、decision和failure。用户正常看到的仍是reportText文字。

| status | 必须满足 |
| --- | --- |
| SUCCEEDED | 正式报告通过校验，reportText及decision存在，无failure |
| SUCCEEDED_WITH_PENDING_DECISION | 有业务结果暂缓但报告合格，reportText及decision存在，无failure |
| FAILED | reportText和对外decision为null，failure存在；诊断中的中间判断仅留内部 |

全空确认后按ER02返回业务待定报告，属于SUCCEEDED_WITH_PENDING_DECISION。模型超时、解析失败或修复耗尽属于FAILED。未成立怀疑但SU04证据不足且又没有合法关键限制时，先作为不一致评估修复，不能静默选择任何业务类别。

# 示例及本轮检查结果

虚构工程样例、拒绝测试和三态样例独立放在E_evaluation/tests/protocol_fixtures_v1_2.json，运行协议与节点装载白名单均不含该目录。样例给定语义前提，只检验程序行为，不作为客户金标准。

本版参考检查69项通过、0项失败：回归旧版11个正向、21个拒绝、5组三态场景，另有32项范围、绑定、问题合并及发布结构检查。检查结果在E_evaluation/tests/protocol_validation_v1_2.json，真实模型调用0次，新批准客户标签0份。

参考检查器覆盖本协议实际使用的schema关键字子集及跨对象约束，不宣称生产JSON Schema库或供应商结构化输出兼容。真实模型语义与项目集成分别验收，不能用协议绿灯替代业务效果。

# 阶段二交付与后续任务

- [x] 四模型节点输入、输出、权限及统一修复响应已定义。

- [x] 事实、原文意见、关注结果、判断、固定映射、审视和草稿已分开。

- [x] 来源定位、可采用集合、关键限制及等级单独受限已表达。

- [x] 共享状态、前序版本、失效规则、技术失败和发布门槛已定义。

- [x] 当前69项参考协议检查通过；运行资源和工程样例分别发布。

- [ ] 按项目实际供应商及版本选择生产JSON Schema与结构化输出适配方式。

- [ ] 使用真实脱敏样本标注并验证节点语义，建立旧流程基线。

- [ ] 在后续阶段编写四份节点提示词及执行流程。

下一步由数据agent B登记完整客户池并按固定配置裁剪，再由C和D在不同会话初标及盲复标，业务裁决后由E建立同范围旧流程基线；F随后编写节点提示词和流程。当前尚无新签发标签、真实基线或生产四节点提示词。
