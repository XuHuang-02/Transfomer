"""Reference contract checks. Covers the schema keywords used here; production-provider compatibility remains unverified."""
import copy
import json
import re
import source_prepare
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUNDLE_PATH = ROOT / 'runtime_protocol_v1_2.json'
bundle = json.loads(BUNDLE_PATH.read_text())
defs = bundle['schema']['$defs']


class ContractError(Exception):
    def __init__(self, code, detail):
        self.code, self.detail = code, detail
        super().__init__(f'{code}: {detail}')


def fail(code, detail):
    raise ContractError(code, detail)


def shape(schema, value, path='$'):
    # Deliberately scoped to the keywords actually used in this protocol draft.
    # This is not a substitute for a production JSON Schema implementation.
    if '$ref' in schema:
        target = schema['$ref']
        assert target.startswith('#/$defs/')
        shape(defs[target.split('/')[-1]], value, path)
    for part in schema.get('allOf', []):
        shape(part, value, path)
    if 'anyOf' in schema:
        for part in schema['anyOf']:
            try:
                shape(part, value, path)
                break
            except ContractError:
                pass
        else:
            fail('OUTPUT_SCHEMA_ERROR', f'{path}: no anyOf alternative')
    if 'const' in schema and value != schema['const']:
        fail('OUTPUT_SCHEMA_ERROR', f'{path}: const')
    if 'enum' in schema and value not in schema['enum']:
        fail('OUTPUT_SCHEMA_ERROR', f'{path}: enum')
    types = schema.get('type')
    if types:
        types = types if isinstance(types, list) else [types]
        matches = {
            'null': value is None,
            'boolean': isinstance(value, bool),
            'integer': isinstance(value, int) and not isinstance(value, bool),
            'number': isinstance(value, (int, float)) and not isinstance(value, bool),
            'string': isinstance(value, str),
            'object': isinstance(value, dict),
            'array': isinstance(value, list),
        }
        if not any(matches.get(t, False) for t in types):
            fail('OUTPUT_SCHEMA_ERROR', f'{path}: type')
    if isinstance(value, dict):
        for key in schema.get('required', []):
            if key not in value:
                fail('OUTPUT_SCHEMA_ERROR', f'{path}.{key}: required')
        props = schema.get('properties', {})
        if schema.get('additionalProperties') is False:
            extra = set(value) - set(props)
            if extra:
                fail('OUTPUT_SCHEMA_ERROR', f'{path}: unexpected {sorted(extra)}')
        for key, sub in props.items():
            if key in value:
                shape(sub, value[key], f'{path}.{key}')
    if isinstance(value, list):
        if len(value) < schema.get('minItems', 0):
            fail('OUTPUT_SCHEMA_ERROR', f'{path}: minItems')
        if schema.get('uniqueItems'):
            keys = [json.dumps(v, sort_keys=True, ensure_ascii=False) for v in value]
            if len(set(keys)) != len(keys):
                fail('OUTPUT_SCHEMA_ERROR', f'{path}: uniqueItems')
        for i, item in enumerate(value):
            if 'items' in schema:
                shape(schema['items'], item, f'{path}[{i}]')
    if isinstance(value, str):
        if len(value) < schema.get('minLength', 0):
            fail('OUTPUT_SCHEMA_ERROR', f'{path}: minLength')
        if 'pattern' in schema and not re.search(schema['pattern'], value):
            fail('OUTPUT_SCHEMA_ERROR', f'{path}: pattern')
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if value < schema.get('minimum', float('-inf')):
            fail('OUTPUT_SCHEMA_ERROR', f'{path}: minimum')


def validate_sources(context):
    shape(defs['SourceContext'], context)
    try:
        source_prepare.validate_view(context)
    except source_prepare.SourceError as error:
        fail(error.code, error.detail)


def validate_quote(context, evidence):
    docs = {d['sourceId']: d for d in context['documents']}
    if evidence['sourceId'] not in docs:
        fail('EVIDENCE_OUT_OF_SCOPE', 'evidence source not in this request view')
    doc = docs[evidence['sourceId']]
    if context['mode'] == 'INDEPENDENT' and doc['origin'] != 'BASE':
        fail('EVIDENCE_OUT_OF_SCOPE', 'independent evidence refers to original')
    blocks = {b['blockId']: b for b in doc['blocks']}
    if evidence['blockId'] not in blocks:
        fail('EVIDENCE_NOT_FOUND', 'unknown block')
    count = blocks[evidence['blockId']]['text'].count(evidence['quote'])
    if count == 0:
        fail('EVIDENCE_NOT_FOUND', 'quote absent from source block')
    if count > 1:
        fail('EVIDENCE_AMBIGUOUS', 'quote must resolve uniquely inside block')


def refs(values, known):
    if not set(values) <= set(known):
        fail('REFERENCE_NOT_FOUND', f'unknown references {sorted(set(values) - set(known))}')


def validate_extraction(context, extraction):
    validate_sources(context)
    shape(defs['ExtractionResult'], extraction)
    fact_ids = [f['factId'] for f in extraction['facts']]
    if len(set(fact_ids)) != len(fact_ids):
        fail('OUTPUT_SCHEMA_ERROR', 'duplicate fact ids')
    for fact in extraction['facts']:
        for evidence in fact['evidence']:
            validate_quote(context, evidence)
        if fact['useStatus'] != 'AVAILABLE' and not fact['useReason']:
            fail('OUTPUT_SCHEMA_ERROR', 'excluded or superseded fact needs reason')
    for statement in extraction['originalStatements']:
        refs(statement['supportingFactIds'], fact_ids)
        for evidence in statement['evidence']:
            validate_quote(context, evidence)
    conflict_ids = [c['conflictId'] for c in extraction['conflicts']]
    if len(set(conflict_ids)) != len(conflict_ids):
        fail('OUTPUT_SCHEMA_ERROR', 'duplicate conflict ids')
    for conflict in extraction['conflicts']:
        refs(conflict['factIds'], fact_ids)
        refs(conflict['adoptedFactIds'], fact_ids)
    available = {f['factId']: f for f in extraction['facts'] if f['useStatus'] == 'AVAILABLE'}
    if not available and not context['emptyFactsConfirmed']:
        fail('EMPTY_EXTRACTION_NEEDS_RECHECK', 'empty extraction is not confirmed empty input')
    return available


def validate_assessment(context, extraction, assessment):
    available = validate_extraction(context, extraction)
    shape(defs['AssessmentResult'], assessment)
    suspicion = assessment['suspicion']
    refs(suspicion['factIds'], available)
    if suspicion['status'] == 'ESTABLISHED':
        if not suspicion['factIds'] or not (suspicion['associationExplanation'] or '').strip():
            fail('INCONSISTENT_ASSESSMENT', 'established suspicion needs facts and association')
        if assessment['focusEvaluation'] != 'EVALUATED':
            fail('INCONSISTENT_ASSESSMENT', 'focus not evaluated after established suspicion')
        if sorted(x['condition'] for x in assessment['focusFindings']) != ['FOCUS_1', 'FOCUS_2', 'FOCUS_3']:
            fail('INCONSISTENT_ASSESSMENT', 'three distinct focus conditions required')
        if assessment['materialBlockers']:
            fail('INCONSISTENT_ASSESSMENT', 'established suspicion cannot also be blocked from classification')
        if assessment['noRiskCriteria'] is not None:
            fail('INCONSISTENT_ASSESSMENT', 'no-risk criteria not evaluated on established branch')
    else:
        if assessment['focusEvaluation'] != 'SKIPPED_BECAUSE_NOT_ESTABLISHED' or assessment['focusFindings']:
            fail('INCONSISTENT_ASSESSMENT', 'focus stage must be skipped before suspicion established')
    for focus in assessment['focusFindings']:
        refs(focus['factIds'], available)
        if focus['status'] == 'SUPPORTED' and (not focus['factIds'] or not focus['explanation']):
            fail('INCONSISTENT_ASSESSMENT', 'supported focus needs facts and explanation')
    for item in assessment['explanationEvaluation'] + assessment['otherAttentionSignals']:
        refs(item['factIds'], available)
    grade = assessment['currentGrade']
    refs(grade['factIds'], available)
    if grade['status'] == 'KNOWN' and (not grade['grade'] or not grade['factIds']):
        fail('INCONSISTENT_ASSESSMENT', 'known grade needs value and fact source')
    if grade['status'] == 'KNOWN':
        eligible = [available[f]['data'] for f in grade['factIds'] if available[f]['data'].get('gradeRecordState') in ['CURRENT_EFFECTIVE', 'EXECUTED_CHANGE']]
        if not any(x.get('riskGrade') == grade['grade'] for x in eligible):
            fail('INCONSISTENT_ASSESSMENT', 'proposed or prior grade cannot establish effective grade')
    if grade['status'] == 'CONFLICT' and (len(grade['factIds']) < 2 or not grade['explanation']):
        fail('INCONSISTENT_ASSESSMENT', 'grade conflict needs competing facts and explanation')
    if grade['status'] != 'KNOWN' and grade['grade'] is not None:
        fail('INCONSISTENT_ASSESSMENT', 'unresolved grade cannot contain selected grade')
    source_ids = {d['sourceId'] for d in context['documents']}
    conflict_ids = {c['conflictId'] for c in extraction['conflicts'] if c['status'] == 'UNRESOLVED'}
    for blocker in assessment['materialBlockers']:
        if blocker['kind'] not in ['INPUT_GAP', 'INPUT_CONFLICT'] or set(blocker['affectedResults']) != {'CLASSIFICATION'}:
            fail('INCONSISTENT_ASSESSMENT', 'assessment blockers are classification-only; grade restrictions are derived separately')
        refs(blocker['factIds'], available)
        refs(blocker['conflictIds'], conflict_ids)
        if set(blocker['checkedSourceIds']) != source_ids:
            fail('INCONSISTENT_ASSESSMENT', 'all allowed sources must be checked for decisive gap or conflict')
        if blocker['kind'] == 'INPUT_CONFLICT' and not blocker['conflictIds']:
            fail('INCONSISTENT_ASSESSMENT', 'conflict blocker needs unresolved conflict')
        if blocker['kind'] == 'INPUT_GAP' and not blocker['missingConcept']:
            fail('INCONSISTENT_ASSESSMENT', 'gap blocker needs decisive missing concept')
    if suspicion['status'] == 'NOT_ESTABLISHED':
        criteria = assessment['noRiskCriteria']
        if criteria is None or assessment['materialBlockers']:
            fail('INCONSISTENT_ASSESSMENT', 'not-established branch needs explicit SU04 criteria')
        for check in criteria.values():
            refs(check['factIds'], available)
            if check['status'] != 'SUPPORTED' or not check['factIds'] or not check['explanation']:
                fail('INCONSISTENT_ASSESSMENT', 'not finding association is not sufficient for no-risk result')
    if suspicion['status'] == 'UNDETERMINED':
        if not assessment['materialBlockers'] or assessment['noRiskCriteria'] is not None:
            fail('INCONSISTENT_ASSESSMENT', 'undetermined classification needs specific decisive blocker')
    return available


LABELS = {
    'classification': {'FOCUS_SUSPICIOUS': '重点可疑', 'GENERAL_SUSPICIOUS': '一般可疑', 'NO_ML_RISK': '无洗钱风险', 'INSUFFICIENT': '当前资料不足以形成分类'},
    'reporting': {'REPORT': '无法排除洗钱嫌疑上报', 'DO_NOT_REPORT': '可排除洗钱嫌疑不上报', 'PENDING': '暂不形成结论'},
    'grade': {'RAISE': '调高风险等级', 'MAINTAIN': '维持原等级', 'PENDING': '暂不形成判定'},
}


def mapped_decision(example):
    context, extraction, assessment = example['context'], example['extraction'], example['assessment']
    available = validate_extraction(context, extraction)
    if not available:
        if assessment is not None:
            fail('INCONSISTENT_ASSESSMENT', 'confirmed empty path cannot swallow a conflicting assessment')
        result = dict(classification='INSUFFICIENT', reporting='PENDING', riskGradeAction='PENDING', basisFactIds=[], constraintDescriptors=[], reason='EMPTY_FACTS')
    else:
        validate_assessment(context, extraction, assessment)
        s = assessment['suspicion']['status']
        constraints = copy.deepcopy(assessment['materialBlockers'])
        if s == 'ESTABLISHED':
            classification = 'FOCUS_SUSPICIOUS' if any(f['status'] == 'SUPPORTED' for f in assessment['focusFindings']) else 'GENERAL_SUSPICIOUS'
            reporting = 'REPORT'
            basis = set(assessment['suspicion']['factIds'])
            for f in assessment['focusFindings']:
                if f['status'] == 'SUPPORTED':
                    basis.update(f['factIds'])
        elif s == 'NOT_ESTABLISHED':
            classification, reporting = 'NO_ML_RISK', 'DO_NOT_REPORT'
            basis = set().union(*(set(x['factIds']) for x in assessment['noRiskCriteria'].values()))
        else:
            classification, reporting = 'INSUFFICIENT', 'PENDING'
            basis = set().union(*(set(x['factIds']) for x in constraints))
        grade = assessment['currentGrade']
        if classification == 'INSUFFICIENT':
            action = 'PENDING'
        elif classification == 'NO_ML_RISK':
            action = 'MAINTAIN'
        elif grade['status'] == 'KNOWN' and grade['grade'] in ['LOW', 'MEDIUM']:
            action = 'RAISE'
        elif grade['status'] == 'KNOWN' and grade['grade'] == 'HIGH':
            action = 'MAINTAIN'
        else:
            action = 'PENDING'
            kind = 'GRADE_UNMAPPED' if grade['status'] == 'KNOWN' else ('GRADE_CONFLICT' if grade['status'] == 'CONFLICT' else 'GRADE_UNKNOWN')
            constraints.append({'blockerId': 'L_GRADE', 'causeKey': 'grade:current_effective', 'kind': kind, 'affectedResults': ['RISK_GRADE'], 'factIds': grade['factIds'], 'conflictIds': [], 'checkedSourceIds': [d['sourceId'] for d in context['documents']], 'missingConcept': 'current_effective_grade' if kind == 'GRADE_UNKNOWN' else None, 'decisiveReason': '现有等级状态或映射类别确实影响本轮维持与调高的选择。'})
        result = dict(classification=classification, reporting=reporting, riskGradeAction=action, basisFactIds=sorted(basis), constraintDescriptors=constraints, reason='ASSESSMENT_MAPPED')
    result.update(suspicionLabel=LABELS['classification'][result['classification']], reportingLabel=LABELS['reporting'][result['reporting']], riskGradeActionLabel=LABELS['grade'][result['riskGradeAction']])
    shape(defs['DecisionResult'], result)
    return result


def assemble_issues(context, decision, review=None):
    validate_sources(context)
    if context['mode'] == 'INDEPENDENT':
        if review and review.get('issues'):
            fail('REVIEW_OVERREACH', 'independent mode cannot publish review issues')
        return []
    original_present = any(d['origin'] == 'ORIGINAL' and d['text'].strip() for d in context['documents'])
    if not original_present and review and review.get('issues'):
        fail('REVIEW_OVERREACH', 'no original document for original-text issues')
    blockers = {b['blockerId']: b for b in decision['constraintDescriptors']}
    groups = {}
    def group(key):
        if key not in groups:
            groups[key] = {'issueId': '', 'causeKey': key, 'origin': 'ASSESSMENT_LIMITATION',
                           'factIds': [], 'blockerIds': [], 'sourceIssueIds': [], 'affectedResults': [],
                           'approvedProblem': None, 'approvedSuggestion': None}
        return groups[key]
    if review is not None:
        shape(defs['ReviewResult'], review)
    for issue in (review or {}).get('issues', []):
        for ev in issue['evidence']:
            validate_quote(context, ev)
        for bid in issue['relatedBlockerIds']:
            if bid not in blockers or blockers[bid]['causeKey'] != issue['causeKey']:
                fail('INCONSISTENT_ISSUE_CAUSE', 'related blocker must share the same root cause')
        g=group(issue['causeKey'])
        g['origin']='ORIGINAL_ISSUE'
        g['factIds'] += issue['factIds']
        g['sourceIssueIds'].append(issue['issueId'])
        for target, source in [('approvedProblem','problem'), ('approvedSuggestion','suggestion')]:
            if not g[target]: g[target]=issue[source]
            elif issue[source] not in g[target]: g[target] += '；' + issue[source]
    for blocker in decision['constraintDescriptors']:
        g=group(blocker['causeKey'])
        g['factIds'] += blocker['factIds']
        g['blockerIds'].append(blocker['blockerId'])
        g['affectedResults'] += blocker['affectedResults']
    for index,g in enumerate(groups.values(),1):
        g['issueId']=f'ISSUE_{index:03d}'
        if g['sourceIssueIds'] and g['blockerIds']: g['origin']='COMBINED'
        for key in ['factIds','blockerIds','sourceIssueIds','affectedResults']:
            g[key]=list(dict.fromkeys(g[key]))
        shape(defs['IssueDescriptor'],g)
    return list(groups.values())


def issue_descriptors(context, decision):
    return assemble_issues(context, decision)



def validate_draft(example, decision, draft, descriptors=None):
    shape(defs['DraftReport'], draft)
    mode = example['context']['mode']
    expected_issues = {x['issueId'] for x in (descriptors if descriptors is not None else issue_descriptors(example['context'], decision))}
    issue_ids = [x['issueId'] for x in draft['issues']]
    if set(issue_ids) != expected_issues or len(set(issue_ids)) != len(issue_ids):
        fail('REPORT_FORMAT_VIOLATION', 'issue ids do not match assembled descriptors')
    kinds = [s['kind'] for s in draft['sections']]
    order = ['IDENTITY', 'BUSINESS', 'FINANCIAL', 'CURRENT_BUSINESS', 'CHECKS', 'CONCLUSION']
    if kinds.count('CONCLUSION') != 1 or kinds[-1] != 'CONCLUSION' or len(set(kinds)) != len(kinds):
        fail('REPORT_FORMAT_VIOLATION', 'unique final conclusion required')
    if kinds != sorted(kinds, key=order.index):
        fail('REPORT_FORMAT_VIOLATION', 'section order')
    if mode == 'INDEPENDENT' and ('CURRENT_BUSINESS' in kinds or draft['issues']):
        fail('REPORT_FORMAT_VIOLATION', 'independent output profile')
    if len(draft['sections'][-1]['paragraphs']) > 2:
        fail('REPORT_FORMAT_VIOLATION', 'conclusion paragraph count')
    available = {f['factId'] for f in example['extraction']['facts'] if f['useStatus'] == 'AVAILABLE'}
    constraints = {b['blockerId']: b for b in decision['constraintDescriptors']}
    seen = set()
    for section in draft['sections']:
        for p in section['paragraphs']:
            refs(p['factIds'], available)
            for c in p['constraintRefs']:
                refs([c['blockerId']], constraints)
                if section['kind'] != 'CONCLUSION':
                    fail('REPORT_FORMAT_VIOLATION', 'limitation reference in fact section')
                if mode == 'COMPREHENSIVE' and c['detail'] != 'STATUS_ONLY':
                    fail('REPORT_FORMAT_VIOLATION', 'comprehensive conclusion repeats limitation cause')
                seen.add(c['blockerId'])
    if mode == 'INDEPENDENT' and seen != set(constraints):
        fail('REPORT_FORMAT_VIOLATION', 'independent conclusion omits decisive limitation')


def check_stamp(stamp, expected):
    shape(defs['ArtifactStamp'], stamp)
    for k in list(source_prepare.BINDING_KEYS) + ['node']:
        if stamp[k] != expected[k]:
            fail('STALE_ARTIFACT', f'{k} mismatch')
    for key, rev in expected['consumedRevisions'].items():
        if stamp['consumedRevisions'].get(key) != rev:
            fail('STALE_ARTIFACT', 'input revision mismatch')


def validate_response(node, response):
    contract = bundle['nodeContracts'][node]
    shape(defs[contract['output']], response)
    if response['status'] == 'COMPLETED':
        if response['result'] is None or response['pipelineFindings']:
            fail('INCONSISTENT_NODE_RESPONSE', 'completed result needs payload and no repair findings')
    else:
        if response['result'] is not None or not response['pipelineFindings']:
            fail('INCONSISTENT_NODE_RESPONSE', 'repair response needs findings and null payload')
        for finding in response['pipelineFindings']:
            if finding['targetNode'] not in contract['canRequestRepairOf']:
                fail('INCONSISTENT_NODE_RESPONSE', 'repair target is outside node authority')



def check_schema_references(value):
    if isinstance(value, dict):
        if '$ref' in value:
            assert value['$ref'].startswith('#/$defs/') and value['$ref'].split('/')[-1] in defs
        for v in value.values():
            check_schema_references(v)
    elif isinstance(value, list):
        for v in value:
            check_schema_references(v)




def validate_binding(actual, context):
    shape(defs['InputBinding'], actual)
    if actual != source_prepare.binding(context):
        fail('STALE_ARTIFACT', 'node input belongs to a different source view or version')


def validate_node_input(node, payload, context):
    validate_sources(context)
    shape(defs[bundle['nodeContracts'][node]['input']], payload)
    validate_binding(payload['binding'], context)
    if node == 'EXTRACT':
        if payload['documents'] != context['documents'] or payload['ruleVersion'] != context['ruleVersion']:
            fail('INPUT_SCOPE_ERROR', 'extractor input differs from prepared view')
    elif node == 'REVIEW':
        originals=[d for d in context['documents'] if d['origin']=='ORIGINAL' and d['text'].strip()]
        if context['mode']!='COMPREHENSIVE' or not originals or payload['originalDocument'] != originals[0]:
            fail('INPUT_SCOPE_ERROR', 'reviewer original document is not authorized')
    if node == 'WRITE':
        original_present=any(d['origin']=='ORIGINAL' and d['text'].strip() for d in context['documents'])
        if payload['mode'] != context['mode'] or payload['originalPresent'] != original_present:
            fail('INPUT_SCOPE_ERROR', 'writer profile differs from source context')
    facts = payload.get('facts', [])
    if isinstance(facts, dict): facts=facts['facts']
    for fact in facts:
        for evidence in fact['evidence']: validate_quote(context,evidence)
        if node in ['ASSESS','WRITE'] and fact['useStatus']!='AVAILABLE':
            fail('EVIDENCE_OUT_OF_SCOPE','assessment and writer accept only available facts')


def validate_annotation(annotation, task, context, coordinator=False):
    schema=json.loads((ROOT/'annotation_schema_v1_2.json').read_text())
    shape(schema, annotation)
    for key,value in task['meta'].items():
        if key!='annotatorId' and annotation['meta'].get(key)!=value:
            fail('STALE_ARTIFACT','annotation task metadata or visible view mismatch')
    status=annotation['coordinatorOnly']['annotationStatus']
    if not coordinator and status!='DRAFT':
        fail('OUTPUT_SCHEMA_ERROR','model cannot approve or freeze labels')
    if not coordinator and any(annotation['coordinatorOnly'][k] is not None for k in
        ['businessReview','expectedDecision','assembledIssues','freezeRecord']):
        fail('OUTPUT_SCHEMA_ERROR','coordinator-only values must remain null in model submissions')
    if annotation['taskState']=='FAILED':
        if not annotation['findings'] or annotation['assessment'] is not None:
            fail('OUTPUT_SCHEMA_ERROR','failed annotation must record execution findings and no assessment')
        return None
    validate_extraction(context,annotation['extraction'])
    if annotation['taskState']=='NEEDS_ADJUDICATION':
        if not annotation['disputes']:
            fail('OUTPUT_SCHEMA_ERROR','adjudication requires an actual dispute')
    elif annotation['assessment'] is None and not context['emptyFactsConfirmed']:
        fail('INCONSISTENT_ASSESSMENT','completed substantive label needs assessment')
    if annotation['assessment'] is not None:
        validate_assessment(context,annotation['extraction'],annotation['assessment'])
    original_present=any(d['origin']=='ORIGINAL' and d['text'].strip() for d in context['documents'])
    expected='SKIPPED_INDEPENDENT' if context['mode']=='INDEPENDENT' else ('RUN' if original_present else 'SKIPPED_NO_ORIGINAL')
    if annotation['reviewApplicability']!=expected:
        fail('OUTPUT_SCHEMA_ERROR','review applicability differs from mode and original presence')
    if expected=='RUN':
        if annotation['review'] is None: fail('OUTPUT_SCHEMA_ERROR','review result required')
        for issue in annotation['review']['issues']:
            for evidence in issue['evidence']: validate_quote(context,evidence)
    elif annotation['review'] is not None:
        fail('REVIEW_OVERREACH','skipped review must be null')
    if status in ['APPROVED','FROZEN']:
        record=annotation['coordinatorOnly']['businessReview']
        if annotation['taskState']!='COMPLETED' or not record or record['viewDigest']!=context['viewDigest']:
            fail('OUTPUT_SCHEMA_ERROR','approved labels need completed matching business review')
        actual=mapped_decision({'context':context,'extraction':annotation['extraction'],'assessment':annotation['assessment']})
        if annotation['coordinatorOnly']['expectedDecision']!=actual:
            fail('RESULT_MAPPING_ERROR','approved reference decision does not match current semantics')
        if status=='FROZEN' and not annotation['coordinatorOnly']['freezeRecord']:
            fail('OUTPUT_SCHEMA_ERROR','frozen label requires freeze record')
    return True
