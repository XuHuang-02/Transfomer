package cn.bugstack.ai.mcp.json.rpc.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.reactive.filter.OrderedWebFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

/**
 * WebFilter配置类
 * 用于配置和注册各种Web过滤器，包括日志过滤器
 *
 * @author xiaofuge bugstack.cn @小傅哥
 */
@Slf4j
@Configuration
public class WebFilterConfig {

    @Autowired
    private LoggingWebFilter loggingWebFilter;

    /**
     * 注册日志过滤器Bean
     * 设置较高的优先级，确保在其他过滤器之前执行
     */
    @Bean
    public OrderedWebFilter orderedLoggingWebFilter() {
        return new OrderedWebFilter() {
            @Override
            public int getOrder() {
                // 设置较高的优先级，在CORS过滤器之后，业务过滤器之前执行
                return Ordered.HIGHEST_PRECEDENCE + 100;
            }

            @Override
            public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
                return loggingWebFilter.filter(exchange, chain);
            }
        };
    }
}