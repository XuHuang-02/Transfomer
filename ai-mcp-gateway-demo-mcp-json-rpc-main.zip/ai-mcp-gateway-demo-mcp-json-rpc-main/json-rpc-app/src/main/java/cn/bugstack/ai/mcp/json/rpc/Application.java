package cn.bugstack.ai.mcp.json.rpc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.function.FunctionToolCallback;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public ToolCallbackProvider tools(AuthService authService) {
        return MethodToolCallbackProvider.builder()
                .toolObjects(authService)
                .build();
    }

    @Slf4j
    @Service
    public static class AuthService {

        @Tool(description = "提问")
        public AuthFunctionResponse ask(AuthFunctionRequest request) {
            return new AuthFunctionResponse("你的提问，" + (request != null ? request.toString() : "null"));
        }

    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class AuthFunctionRequest {

        @JsonProperty(required = true, value = "question")
        @JsonPropertyDescription("提问")
        private String question;

    }

    @Data
    @NoArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class AuthFunctionResponse {

        @JsonProperty(required = true, value = "content")
        @JsonPropertyDescription("content")
        private String content;

        public AuthFunctionResponse(String content) {
            this.content = content;
        }

    }

    public record TextInput(String input) {
    }

    /**
     * 可以执行注册mcp服务
     */
    @Bean
    public ToolCallback toUpperCase() {
        return FunctionToolCallback.builder("toUpperCase", (TextInput input) -> input.input().toUpperCase())
                .inputType(TextInput.class)
                .description("Put the text to upper case")
                .build();
    }

}
