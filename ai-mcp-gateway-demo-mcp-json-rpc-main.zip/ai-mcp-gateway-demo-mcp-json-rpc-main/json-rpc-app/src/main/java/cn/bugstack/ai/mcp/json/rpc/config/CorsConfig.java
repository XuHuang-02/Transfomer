package cn.bugstack.ai.mcp.json.rpc.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.reactive.CorsWebFilter;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

/**
 * CORS跨域配置类，解决前端页面访问后端API时的跨域问题。
 * <p>
 * Access to resource at 'http://localhost:8777/sse' from origin 'http://localhost:63343' has been blocked by CORS policy: No 'Access-Control-Allow-Origin' header is present on the requested resource.
 *
 * @author xiaofuge bugstack.cn @小傅哥
 */
@Slf4j
@Configuration
public class CorsConfig {

    /**
     * 配置CORS过滤器
     * 允许所有域名、所有方法、所有头部的跨域访问
     */
    @Bean
    public CorsWebFilter corsWebFilter() {
        CorsConfiguration corsConfig = new CorsConfiguration();

        // 允许所有域名跨域访问
        corsConfig.addAllowedOriginPattern("*");

        // 允许所有HTTP方法
        corsConfig.addAllowedMethod("*");

        // 允许所有请求头
        corsConfig.addAllowedHeader("*");

        // 允许发送Cookie
        corsConfig.setAllowCredentials(true);

        // 预检请求的缓存时间（秒）
        corsConfig.setMaxAge(3600L);

        // 暴露的响应头，前端可以访问
        corsConfig.setExposedHeaders(Arrays.asList(
                "Content-Type",
                "X-Requested-With",
                "accept",
                "Origin",
                "Access-Control-Request-Method",
                "Access-Control-Request-Headers",
                "Access-Control-Allow-Origin",
                "Access-Control-Allow-Credentials",
                "Cache-Control"
        ));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", corsConfig);

        System.out.println("=== CORS配置已启用 ===");
        System.out.println("允许的域名: *");
        System.out.println("允许的方法: *");
        System.out.println("允许的头部: *");
        System.out.println("允许凭证: true");
        System.out.println("预检缓存时间: 3600秒");

        return new CorsWebFilter(source);
    }
}