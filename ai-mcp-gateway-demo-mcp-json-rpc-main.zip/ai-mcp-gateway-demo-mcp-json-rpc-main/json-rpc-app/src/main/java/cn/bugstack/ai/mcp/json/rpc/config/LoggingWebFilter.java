package cn.bugstack.ai.mcp.json.rpc.config;

import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.http.server.reactive.ServerHttpResponseDecorator;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 请求响应日志过滤器
 * 用于记录所有HTTP请求和响应的详细信息，包括请求参数、请求体、响应体等
 *
 * @author xiaofuge bugstack.cn @小傅哥
 */
@Component
public class LoggingWebFilter implements WebFilter {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    private static final Logger log = LoggerFactory.getLogger(LoggingWebFilter.class);

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        ServerHttpResponse response = exchange.getResponse();

        // 记录请求开始时间
        long startTime = System.currentTimeMillis();
        String requestTime = LocalDateTime.now().format(FORMATTER);

        // 记录请求基本信息
        logRequestInfo(request, requestTime);

        // 包装请求和响应以便记录请求体和响应体
        ServerHttpRequestDecorator requestDecorator = new ServerHttpRequestDecorator(request) {
            @Override
            public Flux<DataBuffer> getBody() {
                return super.getBody().doOnNext(dataBuffer -> {
                    // 记录请求体
                    logRequestBody(dataBuffer, request);
                });
            }
        };

        ServerHttpResponseDecorator responseDecorator = new ServerHttpResponseDecorator(response) {
            @Override
            public Mono<Void> writeWith(org.reactivestreams.Publisher<? extends DataBuffer> body) {
                return super.writeWith(
                    Flux.from(body).doOnNext(dataBuffer -> {
                        // 记录响应体
                        logResponseBody(dataBuffer, response, startTime);
                    })
                );
            }
        };

        // 创建新的交换对象
        ServerWebExchange decoratedExchange = exchange.mutate()
                .request(requestDecorator)
                .response(responseDecorator)
                .build();

        return chain.filter(decoratedExchange)
                .doFinally(signalType -> {
                    // 记录请求完成信息
                    logRequestComplete(request, response, startTime);
                });
    }

    /**
     * 记录请求基本信息
     */
    private void logRequestInfo(ServerHttpRequest request, String requestTime) {
        StringBuilder logBuilder = new StringBuilder();
        logBuilder.append("\n==================== 请求开始 ====================");
        logBuilder.append("\n请求时间: ").append(requestTime);
        logBuilder.append("\n请求方法: ").append(request.getMethod());
        logBuilder.append("\n请求路径: ").append(request.getURI().getPath());
        logBuilder.append("\n请求URL: ").append(request.getURI());
        logBuilder.append("\n客户端IP: ").append(getClientIp(request));
        logBuilder.append("\n请求头信息:");
        
        request.getHeaders().forEach((name, values) -> {
            logBuilder.append("\n  ").append(name).append(": ").append(String.join(", ", values));
        });

        // 记录查询参数
        if (!request.getQueryParams().isEmpty()) {
            logBuilder.append("\n查询参数:");
            request.getQueryParams().forEach((name, values) -> {
                logBuilder.append("\n  ").append(name).append(": ").append(String.join(", ", values));
            });
        }

        log.info(logBuilder.toString());
    }

    /**
     * 记录请求体
     */
    private void logRequestBody(DataBuffer dataBuffer, ServerHttpRequest request) {
        try {
            byte[] bytes = new byte[dataBuffer.readableByteCount()];
            dataBuffer.read(bytes);
            dataBuffer.readPosition(0); // 重置读取位置
            
            String requestBody = new String(bytes, StandardCharsets.UTF_8);
            if (!requestBody.trim().isEmpty()) {
                log.info("\n请求体内容:\n{}", requestBody);
            }
        } catch (Exception e) {
            log.warn("读取请求体失败: {}", e.getMessage());
        }
    }

    /**
     * 记录响应体
     */
    private void logResponseBody(DataBuffer dataBuffer, ServerHttpResponse response, long startTime) {
        try {
            byte[] bytes = new byte[dataBuffer.readableByteCount()];
            dataBuffer.read(bytes);
            dataBuffer.readPosition(0); // 重置读取位置
            
            String responseBody = new String(bytes, StandardCharsets.UTF_8);
            
            StringBuilder logBuilder = new StringBuilder();
            logBuilder.append("\n响应状态码: ").append(response.getStatusCode());
            logBuilder.append("\n响应头信息:");
            response.getHeaders().forEach((name, values) -> {
                logBuilder.append("\n  ").append(name).append(": ").append(String.join(", ", values));
            });
            
            if (!responseBody.trim().isEmpty()) {
                logBuilder.append("\n响应体内容:\n").append(responseBody);
            }
            
            log.info(logBuilder.toString());
        } catch (Exception e) {
            log.warn("读取响应体失败: {}", e.getMessage());
        }
    }

    /**
     * 记录请求完成信息
     */
    private void logRequestComplete(ServerHttpRequest request, ServerHttpResponse response, long startTime) {
        long duration = System.currentTimeMillis() - startTime;
        String completeTime = LocalDateTime.now().format(FORMATTER);
        
        StringBuilder logBuilder = new StringBuilder();
        logBuilder.append("\n完成时间: ").append(completeTime);
        logBuilder.append("\n处理耗时: ").append(duration).append("ms");
        logBuilder.append("\n==================== 请求结束 ====================\n");
        
        log.info(logBuilder.toString());
    }

    /**
     * 获取客户端真实IP地址
     */
    private String getClientIp(ServerHttpRequest request) {
        String xForwardedFor = request.getHeaders().getFirst("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty() && !"unknown".equalsIgnoreCase(xForwardedFor)) {
            return xForwardedFor.split(",")[0].trim();
        }
        
        String xRealIp = request.getHeaders().getFirst("X-Real-IP");
        if (xRealIp != null && !xRealIp.isEmpty() && !"unknown".equalsIgnoreCase(xRealIp)) {
            return xRealIp;
        }
        
        String remoteAddr = request.getRemoteAddress() != null ? 
            request.getRemoteAddress().getAddress().getHostAddress() : "unknown";
        
        return remoteAddr;
    }
}