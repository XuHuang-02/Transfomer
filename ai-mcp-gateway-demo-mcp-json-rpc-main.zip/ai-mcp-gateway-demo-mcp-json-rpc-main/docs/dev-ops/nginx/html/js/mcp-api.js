let eventSource = null;
let currentSessionId = null;
let messageEndpoint = null;
let messageIdCounter = 1;

// 日志记录函数
function addLog(message, type = 'info') {
    const log = document.getElementById('log');
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = document.createElement('div');
    logEntry.className = `log-entry ${type}`;
    logEntry.innerHTML = `<span class="timestamp">[${timestamp}]</span> ${message}`;
    log.appendChild(logEntry);
    log.scrollTop = log.scrollHeight;
}

// 清空日志
function clearLog() {
    document.getElementById('log').innerHTML = '';
    addLog('日志已清空', 'info');
}

// 更新连接状态
function updateConnectionStatus(status, message) {
    const statusElement = document.getElementById('connectionStatus');
    const connectBtn = document.getElementById('connectBtn');
    const disconnectBtn = document.getElementById('disconnectBtn');
    const sendBtn = document.getElementById('sendBtn');

    statusElement.className = `status ${status}`;
    statusElement.textContent = `状态：${message}`;

    if (status === 'connected') {
        connectBtn.disabled = true;
        disconnectBtn.disabled = false;
        sendBtn.disabled = false;
    } else {
        connectBtn.disabled = false;
        disconnectBtn.disabled = true;
        sendBtn.disabled = true;
    }
}

// 更新会话信息显示
function updateSessionInfo() {
    const sessionInfo = document.getElementById('sessionInfo');
    if (currentSessionId && messageEndpoint) {
        sessionInfo.innerHTML = `
            会话ID: ${currentSessionId}<br>
            消息端点: ${messageEndpoint}
        `;
    } else {
        sessionInfo.textContent = '未连接';
    }
}

// 建立SSE连接
function connectSSE() {
    const serverUrl = document.getElementById('serverUrl').value.trim();
    const sessionId = document.getElementById('sessionId').value.trim();
    
    if (!serverUrl) {
        addLog('请输入服务器地址', 'error');
        return;
    }

    updateConnectionStatus('connecting', '连接中...');
    addLog(`正在连接到: ${serverUrl}/sse`, 'info');

    let url = `${serverUrl}/sse`;
    if (sessionId) {
        url += `?sessionId=${encodeURIComponent(sessionId)}`;
        addLog(`使用指定会话ID: ${sessionId}`, 'info');
    }

    // 先测试服务器是否可达
    addLog('正在检查服务器连通性...', 'info');
    
    try {
        // 创建EventSource时添加错误处理
        eventSource = new EventSource(url);

        // 设置连接超时
        const connectionTimeout = setTimeout(() => {
            if (eventSource && eventSource.readyState === EventSource.CONNECTING) {
                addLog('连接超时，可能是CORS问题或服务器未启动', 'error');
                addLog('解决方案：', 'warning');
                addLog('1. 确保MCP服务器已启动并运行在端口8777', 'warning');
                addLog('2. 检查服务器是否配置了CORS策略', 'warning');
                addLog('3. 尝试在同一域名下访问（如直接打开文件而不是通过IDE服务器）', 'warning');
                disconnectSSE();
            }
        }, 10000); // 10秒超时

        eventSource.onopen = function(event) {
            clearTimeout(connectionTimeout);
            updateConnectionStatus('connected', '已连接');
            addLog('SSE 连接建立成功', 'success');
        };

        // 默认message事件处理器 - 兼容服务器未指定事件名的消息
        eventSource.onmessage = function(event) {
            handleJsonRpcEvent(event);
        };

        eventSource.addEventListener('endpoint', function(event) {
            messageEndpoint = event.data;
            // 从端点URL中提取sessionId
            const match = messageEndpoint.match(/sessionId=([^&]+)/);
            if (match) {
                currentSessionId = decodeURIComponent(match[1]);
                document.getElementById('sessionId').value = currentSessionId;
            }
            updateSessionInfo();
            addLog(`收到消息端点: ${messageEndpoint}`, 'success');

            // 自动进行 MCP 初始化握手，避免未初始化导致无响应
            try {
                addLog('自动发送 initialize 握手...', 'info');
                sendInitialize();
                // 小延迟后发送，确保端点与会话已更新
                setTimeout(() => {
                    sendMessage();
                }, 200);
            } catch (e) {
                addLog(`自动初始化失败: ${e.message}`, 'error');
            }
        });

        // JSON-RPC 响应事件处理器（命名事件：message）
        eventSource.addEventListener('message', function(event) {
            handleJsonRpcEvent(event);
        });

        // 统一处理 JSON-RPC 响应（支持默认事件与命名事件）
        function handleJsonRpcEvent(event) {
            if (!event || !event.data) {
                addLog('收到空的 SSE 事件', 'warning');
                return;
            }
            addLog(`📨 收到JSON-RPC响应: ${event.data}`, 'success');
            try {
                const response = JSON.parse(event.data);
                addLog(`📋 解析的响应内容:`, 'info');
                addLog(`${JSON.stringify(response, null, 2)}`, 'info');

                // 错误响应优先处理
                if (response.error) {
                    addLog(`❌ 错误响应: ${response.error.message}`, 'error');
                    if (response.error.data) {
                        addLog(`错误详情: ${JSON.stringify(response.error.data, null, 2)}`, 'error');
                    }
                    return;
                }

                // 工具列表响应
                if (response.result && response.result.tools) {
                    addLog(`🔧 发现 ${response.result.tools.length} 个可用工具:`, 'success');
                    response.result.tools.forEach((tool, index) => {
                        addLog(`  ${index + 1}. ${tool.name}: ${tool.description || '无描述'}`, 'info');
                    });
                    return;
                }

                // 工具调用响应（兼容不同返回结构）
                if (response.result) {
                    const text = extractResultText(response.result);
                    if (text) {
                        addLog(`🔁 工具调用结果: ${text}`, 'success');
                    }
                }
            } catch (e) {
                addLog(`❌ 响应解析失败: ${e.message}`, 'warning');
                addLog(`原始响应: ${event.data}`, 'warning');
            }
        }

        // 从多种可能的返回结构中提取文本内容
        function extractResultText(result) {
            // 情况1：直接是字符串
            if (typeof result === 'string') return result;

            // 情况2：{ content: 'xxx' }
            if (result && typeof result.content === 'string') return result.content;

            // 情况3：{ content: [{ type: 'text', text: 'xxx' }, ...] }
            if (Array.isArray(result?.content)) {
                const texts = result.content
                    .filter(item => item && (item.text || item.data || item.content))
                    .map(item => item.text || item.data || item.content)
                    .filter(Boolean);
                if (texts.length) return texts.join('\n');
            }

            // 情况4：{ output: 'xxx' } 或 { data: 'xxx' }
            if (typeof result.output === 'string') return result.output;
            if (typeof result.data === 'string') return result.data;

            // 情况5：嵌套对象里可能包含 text 字段
            try {
                const possible = JSON.stringify(result);
                const match = possible.match(/\"text\"\s*:\s*\"([^\"]+)\"/);
                if (match) return match[1];
            } catch (_) {}

            return '';
        }

        eventSource.addEventListener('ping', function(event) {
            addLog('收到心跳信号', 'info');
        });

        eventSource.addEventListener('notification', function(event) {
            addLog(`收到通知: ${event.data}`, 'warning');
        });

        eventSource.onerror = function(event) {
            clearTimeout(connectionTimeout);
            addLog('SSE 连接发生错误', 'error');
            
            // 详细的错误诊断
            if (eventSource.readyState === EventSource.CLOSED) {
                addLog('连接已关闭', 'error');
            } else if (eventSource.readyState === EventSource.CONNECTING) {
                addLog('连接中断，正在重试...', 'warning');
            }
            
            addLog('可能的原因：', 'warning');
            addLog('1. CORS策略阻止了跨域请求', 'warning');
            addLog('2. 服务器未启动或端口不正确', 'warning');
            addLog('3. 网络连接问题', 'warning');
            
            updateConnectionStatus('disconnected', '连接错误');
            currentSessionId = null;
            messageEndpoint = null;
            updateSessionInfo();
        };

    } catch (error) {
        addLog(`连接失败: ${error.message}`, 'error');
        updateConnectionStatus('disconnected', '连接失败');
    }
}

// 断开SSE连接
function disconnectSSE() {
    if (eventSource) {
        eventSource.close();
        eventSource = null;
    }
    updateConnectionStatus('disconnected', '已断开');
    addLog('SSE 连接已断开', 'info');
    currentSessionId = null;
    messageEndpoint = null;
    updateSessionInfo();
}

// 测试服务器连通性
function testServerConnectivity() {
    const serverUrl = document.getElementById('serverUrl').value.trim();
    
    if (!serverUrl) {
        addLog('请输入服务器地址', 'error');
        return;
    }

    addLog('开始测试服务器连通性...', 'info');
    addLog(`测试地址: ${serverUrl}/mcp/status`, 'info');

    // 首先测试状态端点
    fetch(`${serverUrl}/mcp/status`, {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
        },
        mode: 'cors' // 明确指定CORS模式
    })
    .then(response => {
        addLog(`状态端点响应: ${response.status} ${response.statusText}`, response.ok ? 'success' : 'warning');
        if (response.ok) {
            return response.json();
        } else {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
    })
    .then(data => {
        addLog(`服务器状态: ${JSON.stringify(data, null, 2)}`, 'success');
        addLog('✅ 服务器连通性测试成功！可以尝试建立SSE连接', 'success');
    })
    .catch(error => {
        addLog(`❌ 状态端点测试失败: ${error.message}`, 'error');
        
        // 如果状态端点失败，尝试直接测试SSE端点
        addLog('尝试测试SSE端点...', 'info');
        testSSEEndpoint(serverUrl);
    });
}

// 测试SSE端点
function testSSEEndpoint(serverUrl) {
    const testUrl = `${serverUrl}/sse`;
    addLog(`测试SSE端点: ${testUrl}`, 'info');

    // 创建一个临时的EventSource来测试连接
    const testEventSource = new EventSource(testUrl);
    
    const testTimeout = setTimeout(() => {
        testEventSource.close();
        addLog('❌ SSE端点连接超时', 'error');
        addLog('可能的问题：', 'warning');
        addLog('1. 服务器未启动或端口错误', 'warning');
        addLog('2. CORS策略阻止了跨域请求', 'warning');
        addLog('3. 防火墙或网络问题', 'warning');
        showCORSHelp();
    }, 5000);

    testEventSource.onopen = function() {
        clearTimeout(testTimeout);
        testEventSource.close();
        addLog('✅ SSE端点连接成功！', 'success');
        addLog('服务器可以正常访问，可以建立正式连接', 'success');
    };

    testEventSource.onerror = function() {
        clearTimeout(testTimeout);
        testEventSource.close();
        addLog('❌ SSE端点连接失败', 'error');
        showCORSHelp();
    };
}

// 显示CORS帮助信息
function showCORSHelp() {
    addLog('🔧 CORS问题解决方案：', 'warning');
    addLog('方案1: 直接打开HTML文件', 'info');
    addLog('  - 在文件管理器中双击HTML文件', 'info');
    addLog('  - 或在浏览器地址栏输入: file:///path/to/mcp-api-test.html', 'info');
    addLog('方案2: 启动Chrome时禁用安全策略', 'info');
    addLog('  - 关闭所有Chrome窗口', 'info');
    addLog('  - 使用命令启动: chrome --disable-web-security --user-data-dir=/tmp/chrome_dev', 'info');
    addLog('方案3: 配置MCP服务器CORS', 'info');
    addLog('  - 在服务器端添加CORS头: Access-Control-Allow-Origin: *', 'info');
    addLog('方案4: 使用本地HTTP服务器', 'info');
    addLog('  - python -m http.server 8000', 'info');
    addLog('  - 然后访问: http://localhost:8000/mcp-api-test.html', 'info');
}

// 发送消息
function sendMessage() {
    if (!currentSessionId || !messageEndpoint) {
        addLog('请先建立 SSE 连接', 'error');
        return;
    }

    const serverUrl = document.getElementById('serverUrl').value.trim();
    const method = document.getElementById('messageMethod').value;
    const customMethod = document.getElementById('customMethod').value.trim();
    const paramsText = document.getElementById('messageParams').value.trim();
    let messageId = document.getElementById('messageId').value.trim();

    if (!messageId) {
        messageId = messageIdCounter++;
        document.getElementById('messageId').value = messageId;
    }

    const actualMethod = method === 'custom' ? customMethod : method;
    if (!actualMethod) {
        addLog('请选择或输入方法名', 'error');
        return;
    }

    let params = {};
    if (paramsText) {
        try {
            params = JSON.parse(paramsText);
        } catch (e) {
            addLog(`参数JSON格式错误: ${e.message}`, 'error');
            return;
        }
    }

    const message = {
        jsonrpc: "2.0",
        method: actualMethod,
        params: params,
        id: messageId
    };

    // messageEndpoint 已经包含了完整的路径和sessionId参数
    const url = messageEndpoint.startsWith('http') ? messageEndpoint : `${serverUrl}${messageEndpoint}`;
    addLog(`发送消息到: ${url}`, 'info');
    addLog(`消息内容: ${JSON.stringify(message, null, 2)}`, 'info');

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(message)
    })
    .then(response => {
        addLog(`HTTP响应状态: ${response.status} ${response.statusText}`, 'info');
        
        // MCP服务器通过SSE返回响应，HTTP响应体通常为空
        if (response.ok) {
            addLog('✅ 消息发送成功，等待SSE响应...', 'success');
            addLog('💡 响应将通过SSE事件流返回，请查看上方的SSE消息', 'info');
        } else {
            addLog(`❌ HTTP请求失败: ${response.status} ${response.statusText}`, 'error');
            if (response.status === 404) {
                addLog('可能原因：Session 不存在或已过期，请重新建立 SSE 连接', 'warning');
            } else if (response.status === 400) {
                addLog('可能原因：请求格式错误或缺少参数，请检查JSON-RPC消息', 'warning');
            } else if (response.status === 503) {
                addLog('服务器正在关闭或不可用，请稍后重试', 'warning');
            }
        }
        
        // 检查响应是否有内容
        const contentLength = response.headers.get('content-length');
        if (contentLength && contentLength !== '0') {
            return response.text(); // 使用text()而不是json()以避免解析错误
        } else {
            return Promise.resolve(''); // 返回空字符串
        }
    })
    .then(data => {
        if (data && data.trim()) {
            addLog(`HTTP响应内容: ${data}`, 'info');
            // 尝试解析为JSON
            try {
                const jsonData = JSON.parse(data);
                addLog(`解析的JSON响应: ${JSON.stringify(jsonData, null, 2)}`, 'success');
            } catch (e) {
                addLog(`响应不是JSON格式: ${data}`, 'info');
            }
        }
    })
    .catch(error => {
        addLog(`发送失败: ${error.message}`, 'error');
    });
}

// 快速发送预定义消息
function sendInitialize() {
    document.getElementById('messageMethod').value = 'initialize';
    document.getElementById('messageParams').value = JSON.stringify({
        protocolVersion: "2024-11-05",
        capabilities: {
            tools: {},
            resources: {}
        },
        clientInfo: {
            name: "MCP Test Client",
            version: "1.0.0"
        }
    }, null, 2);
    document.getElementById('messageId').value = messageIdCounter++;
    // 立即发送初始化消息，避免遗漏握手
    sendMessage();
}

function sendToolsList() {
    document.getElementById('messageMethod').value = 'tools/list';
    document.getElementById('messageParams').value = '{}';
    document.getElementById('messageId').value = messageIdCounter++;
    // 立即发送工具列表请求
    sendMessage();
}

function sendResourcesList() {
    document.getElementById('messageMethod').value = 'resources/list';
    document.getElementById('messageParams').value = '{}';
    document.getElementById('messageId').value = messageIdCounter++;
    // 立即发送资源列表请求
    sendMessage();
}

function sendToolCall() {
    document.getElementById('messageMethod').value = 'tools/call';
    document.getElementById('messageParams').value = JSON.stringify({
        name: "toUpperCase",
        arguments: {
            input: "mcp gateway: 小写转换为大写"
        }
    }, null, 2);
    document.getElementById('messageId').value = messageIdCounter++;
    // 立即发送工具调用请求
    sendMessage();
}

// 方法选择变化处理
document.getElementById('messageMethod').addEventListener('change', function() {
    const customMethodInput = document.getElementById('customMethod');
    if (this.value === 'custom') {
        customMethodInput.disabled = false;
        customMethodInput.focus();
    } else {
        customMethodInput.disabled = true;
        customMethodInput.value = '';
    }
});

// 页面加载完成后的初始化
document.addEventListener('DOMContentLoaded', function() {
    addLog('MCP API 测试工具已加载完成', 'success');
    addLog('使用说明：', 'info');
    addLog('1. 输入服务器地址（默认 http://localhost:8777）', 'info');
    addLog('2. 点击"建立连接"按钮建立 SSE 连接', 'info');
    addLog('3. 连接成功后会自动获取 sessionId 和消息端点', 'info');
    addLog('4. 选择要测试的方法或使用快捷按钮', 'info');
    addLog('5. 点击"发送消息"发送 JSON-RPC 请求', 'info');
    addLog('6. 在日志中查看服务器响应', 'info');
});